package com.rosstudent.app.enums

enum class AuthTabEnum(val title: String) {
    Login("Вход"),
    Registration("Регистрация")
}