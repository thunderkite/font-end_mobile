package com.rosstudent.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class TaskStore(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        "task_preferences",
        Context.MODE_PRIVATE
    )
    
    private val json = Json { ignoreUnknownKeys = true }
    
    // Получить все задачи
    fun getAllTasks(): List<Task> {
        val taskJson = sharedPreferences.getString(KEY_TASKS, null) ?: return emptyList()
        return try {
            json.decodeFromString(taskJson)
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Получить задачи по типу и приоритету
    fun getTasksByTypeAndPriority(typeId: String? = null, priority: TaskPriority? = null): List<Task> {
        val allTasks = getAllTasks()
        return allTasks.filter { task ->
            (typeId == null || getTaskTypeById(typeId) == task.type) && 
            (priority == null || task.priority == priority) &&
            !task.isDeleted
        }
    }
    
    // Получить задачи для конкретной группы
    fun getTasksByGroup(groupId: String): List<Task> {
        val allTasks = getAllTasks()
        return allTasks.filter { task ->
            task.groupId == groupId && !task.isDeleted
        }
    }
    
    // Получить выполненные задачи пользователя
    fun getCompletedTasksForUser(userId: String): List<CompletedTask> {
        val completedJson = sharedPreferences.getString(KEY_COMPLETED_TASKS, null) ?: return emptyList()
        return try {
            val allCompleted: List<CompletedTask> = json.decodeFromString(completedJson)
            allCompleted.filter { it.userId == userId }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Проверить, выполнена ли задача пользователем
    fun isTaskCompletedByUser(taskId: String, userId: String): Boolean {
        val completedTasks = getCompletedTasksForUser(userId)
        return completedTasks.any { it.taskId == taskId }
    }
    
    // Добавить новую задачу
    fun addTask(task: Task) {
        val tasks = getAllTasks().toMutableList()
        tasks.add(task)
        saveTasks(tasks)
    }
    
    // Обновить задачу
    fun updateTask(updatedTask: Task) {
        val tasks = getAllTasks().toMutableList()
        val index = tasks.indexOfFirst { it.id == updatedTask.id }
        if (index != -1) {
            tasks[index] = updatedTask
            saveTasks(tasks)
        }
    }
    
    // Удалить задачу (пометить как удаленную)
    fun deleteTask(taskId: String) {
        val tasks = getAllTasks().toMutableList()
        val index = tasks.indexOfFirst { it.id == taskId }
        if (index != -1) {
            val task = tasks[index]
            tasks[index] = task.copy(isDeleted = true)
            saveTasks(tasks)
        }
    }
    
    // Отметить задачу как выполненную
    fun markTaskCompleted(taskId: String, userId: String) {
        val completedTasks = getAllCompletedTasks().toMutableList()
        if (completedTasks.none { it.taskId == taskId && it.userId == userId }) {
            completedTasks.add(CompletedTask(
                userId = userId,
                taskId = taskId,
                completedAt = System.currentTimeMillis()
            ))
            saveCompletedTasks(completedTasks)
        }
    }
    
    // Получить все вопросы для задачи
    fun getQuestionsForTask(taskId: String): List<Question> {
        val questionsJson = sharedPreferences.getString(KEY_QUESTIONS, null) ?: return emptyList()
        return try {
            val allQuestions: List<Question> = json.decodeFromString(questionsJson)
            allQuestions.filter { it.taskId == taskId }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Получить все варианты ответов для вопроса
    fun getOptionsForQuestion(questionId: String): List<QuestionOption> {
        val optionsJson = sharedPreferences.getString(KEY_OPTIONS, null) ?: return emptyList()
        return try {
            val allOptions: List<QuestionOption> = json.decodeFromString(optionsJson)
            allOptions.filter { it.questionId == questionId }
                .sortedBy { it.optionOrder }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Добавить вопрос к задаче
    fun addQuestion(question: Question): String {
        val questions = getAllQuestions().toMutableList()
        questions.add(question)
        saveQuestions(questions)
        return question.questionId
    }
    
    // Добавить варианты ответов для вопроса
    fun addOptionsForQuestion(questionId: String, options: List<String>) {
        val allOptions = getAllOptions().toMutableList()
        options.forEachIndexed { index, optionText ->
            allOptions.add(QuestionOption(
                optionId = "${questionId}_${index}",
                questionId = questionId,
                optionText = optionText,
                optionOrder = index
            ))
        }
        saveOptions(allOptions)
    }
    
    // Сохранить ответ пользователя
    fun saveAnswer(answer: Answer) {
        val answers = getAllAnswers().toMutableList()
        answers.add(answer)
        saveAnswers(answers)
    }
    
    // Сохранить выбранные варианты ответов
    fun saveSelectedOptions(answerId: String, optionIds: List<String>) {
        val selectedOptions = getAllSelectedOptions().toMutableList()
        optionIds.forEach { optionId ->
            selectedOptions.add(SelectedOption(
                answerId = answerId,
                optionId = optionId
            ))
        }
        saveSelectedOptions(selectedOptions)
    }
    
    // Получить ответы пользователя на задачу
    fun getUserAnswersForTask(userId: String, taskId: String): Map<String, Answer> {
        val questions = getQuestionsForTask(taskId)
        val questionIds = questions.map { it.questionId }
        val answers = getAllAnswers().filter { answer -> 
            answer.userId == userId && questionIds.contains(answer.questionId) 
        }
        return answers.associateBy { it.questionId }
    }
    
    // Получить выбранные варианты для ответа
    fun getSelectedOptionsForAnswer(answerId: String): List<String> {
        return getAllSelectedOptions()
            .filter { it.answerId == answerId }
            .map { it.optionId }
    }
    
    // Получить приоритет по ID
    private fun getPriorityById(priorityId: String): TaskPriority? {
        return when(priorityId) {
            "1" -> TaskPriority.NORMAL
            "2" -> TaskPriority.URGENT
            "3" -> TaskPriority.ARCHIVED
            else -> null
        }
    }
    
    // Получить тип задачи по ID
    private fun getTaskTypeById(typeId: String): TaskType? {
        return when(typeId) {
            "1" -> TaskType.FEDERAL
            "2" -> TaskType.EDUCATIONAL
            "3" -> TaskType.HEADMAN
            else -> null
        }
    }
    
    // Сохранить список задач
    private fun saveTasks(tasks: List<Task>) {
        val tasksJson = json.encodeToString(tasks)
        sharedPreferences.edit().putString(KEY_TASKS, tasksJson).apply()
    }
    
    // Получить все выполненные задачи
    private fun getAllCompletedTasks(): List<CompletedTask> {
        val completedJson = sharedPreferences.getString(KEY_COMPLETED_TASKS, null) ?: return emptyList()
        return try {
            json.decodeFromString(completedJson)
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Сохранить список выполненных задач
    private fun saveCompletedTasks(completedTasks: List<CompletedTask>) {
        val completedJson = json.encodeToString(completedTasks)
        sharedPreferences.edit().putString(KEY_COMPLETED_TASKS, completedJson).apply()
    }
    
    // Получить все вопросы
    private fun getAllQuestions(): List<Question> {
        val questionsJson = sharedPreferences.getString(KEY_QUESTIONS, null) ?: return emptyList()
        return try {
            json.decodeFromString(questionsJson)
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Сохранить список вопросов
    private fun saveQuestions(questions: List<Question>) {
        val questionsJson = json.encodeToString(questions)
        sharedPreferences.edit().putString(KEY_QUESTIONS, questionsJson).apply()
    }
    
    // Получить все варианты ответов
    private fun getAllOptions(): List<QuestionOption> {
        val optionsJson = sharedPreferences.getString(KEY_OPTIONS, null) ?: return emptyList()
        return try {
            json.decodeFromString(optionsJson)
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Сохранить список вариантов ответов
    private fun saveOptions(options: List<QuestionOption>) {
        val optionsJson = json.encodeToString(options)
        sharedPreferences.edit().putString(KEY_OPTIONS, optionsJson).apply()
    }
    
    // Получить все ответы
    private fun getAllAnswers(): List<Answer> {
        val answersJson = sharedPreferences.getString(KEY_ANSWERS, null) ?: return emptyList()
        return try {
            json.decodeFromString(answersJson)
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Сохранить список ответов
    private fun saveAnswers(answers: List<Answer>) {
        val answersJson = json.encodeToString(answers)
        sharedPreferences.edit().putString(KEY_ANSWERS, answersJson).apply()
    }
    
    // Получить все выбранные варианты
    private fun getAllSelectedOptions(): List<SelectedOption> {
        val selectedJson = sharedPreferences.getString(KEY_SELECTED_OPTIONS, null) ?: return emptyList()
        return try {
            json.decodeFromString(selectedJson)
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    // Сохранить список выбранных вариантов
    private fun saveSelectedOptions(selectedOptions: List<SelectedOption>) {
        val selectedJson = json.encodeToString(selectedOptions)
        sharedPreferences.edit().putString(KEY_SELECTED_OPTIONS, selectedJson).apply()
    }
    
    companion object {
        private const val KEY_TASKS = "tasks"
        private const val KEY_COMPLETED_TASKS = "completed_tasks"
        private const val KEY_QUESTIONS = "questions"
        private const val KEY_OPTIONS = "question_options"
        private const val KEY_ANSWERS = "answers"
        private const val KEY_SELECTED_OPTIONS = "selected_options"
    }
} 