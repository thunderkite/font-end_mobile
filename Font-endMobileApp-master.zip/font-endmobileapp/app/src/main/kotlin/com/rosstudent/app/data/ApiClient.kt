package com.rosstudent.app.data



// TODO: Мега-рефакторинг!!!!

//@SuppressLint("UnsafeOptInUsageError")
//@Serializable
//data class Student(
//    val id: Int,
//    val firstName: String,
//    val lastName: String,
//    val middleName: String? = null,
//    val group: String,
//    var isSelected: Boolean = false
//)
//
//@SuppressLint("UnsafeOptInUsageError")
//@Serializable
//data class StudentsResponse(
//    val students: List<Student>
//)

class ApiClient {

} 