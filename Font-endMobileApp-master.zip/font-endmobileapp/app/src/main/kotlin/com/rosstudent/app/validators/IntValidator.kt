package com.rosstudent.app.validators

// TODO: локализовать
class IntValidator(
    private val min: Int? = null,
    private val max: Int? = null,
    private val allowNull: Boolean = false
) : Validator<String> {
    override fun validate(value: String): ValidationResult {
        if (value.isBlank()) {
            return if (allowNull) ValidationResult.Success
            else ValidationResult.Error("Поле не может быть пустым")
        }

        val intValue = value.toIntOrNull()
            ?: return ValidationResult.Error("Некорректное число")

        min?.let {
            if (intValue < it) return ValidationResult.Error("Значение должно быть не менее $it")
        }

        max?.let {
            if (intValue > it) return ValidationResult.Error("Значение должно быть не более $it")
        }

        return ValidationResult.Success
    }
}