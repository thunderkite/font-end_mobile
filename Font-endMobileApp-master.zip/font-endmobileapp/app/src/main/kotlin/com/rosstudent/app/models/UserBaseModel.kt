package com.rosstudent.app.models

import com.rosstudent.app.enums.RolesType
import kotlinx.serialization.InternalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

@Serializable
sealed class UserBaseModel {
    abstract val userId: String
    abstract val firstName: String
    abstract val lastName: String
    abstract val email: String
    abstract val middleName: String?
    abstract val role: RolesType

    companion object {
        val json by lazy {
            Json {
                classDiscriminator = "userType"
                ignoreUnknownKeys = true
                serializersModule = SerializersModule {
                    polymorphic(UserBaseModel::class) {
                        subclass(GuestUserModel::class)
                        subclass(StudentModel::class)
                    }
                }
            }
        }
    }
}
