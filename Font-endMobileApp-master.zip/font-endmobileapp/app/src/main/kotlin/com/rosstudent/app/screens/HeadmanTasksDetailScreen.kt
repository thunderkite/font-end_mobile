package com.rosstudent.app.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.navigation.Screen
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.ui.res.stringResource

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeadmanTasksDetailScreen(navController: NavController) {
    Scaffold(
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.home_high),
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Main.route)
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_document),
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Tasks.route)
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_gift),
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Gifts.route)
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_menu),
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Schedule.route)
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.reaccount),
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    navController.navigate("create_task")
                },
                containerColor = Color(0xFFE94F09),
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "add a task")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(top = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.tasks_for_the_headman),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            var selectedTab by remember { mutableStateOf(0) }
            Row(
                modifier = Modifier.padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val tabTitles = listOf("Актуальное", "Срочные", "Архив")
                tabTitles.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    Button(
                        onClick = { selectedTab = index },
                        colors = if (isSelected)
                            ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09))
                        else
                            ButtonDefaults.outlinedButtonColors(containerColor = Color.White),
                        border = if (!isSelected) BorderStroke(1.dp, Color(0xFFE94F09)) else null,
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
                        elevation = null,
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(
                            text = title,
                            color = if (isSelected) Color.White else Color(0xFFE94F09),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            Image(
                painter = painterResource(id = R.drawable.ex_1),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.ex_1),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.ex_2),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.ex_2),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.ex_3),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.ex_3),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
            )
        }
    }
} 