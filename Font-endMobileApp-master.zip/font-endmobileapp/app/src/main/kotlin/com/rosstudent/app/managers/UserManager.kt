package com.rosstudent.app.managers

import android.content.Context.MODE_PRIVATE
import android.util.Log
import com.rosstudent.app.enums.RolesType
import com.rosstudent.app.models.UserBaseModel
import androidx.core.content.edit
import com.rosstudent.app.constants.ContextKeys

object UserManager {

    @Volatile
    private var currentUser: UserBaseModel? = null
    private val lock = Any()

    fun saveUser(user: UserBaseModel) {
        synchronized(lock) {
            currentUser = user
            val prefs = ContextManager.getContext()
                .getSharedPreferences(ContextKeys.PREFS_NAME, MODE_PRIVATE)

            // Используем полиморфную сериализацию
            val json = UserBaseModel.json.encodeToString(user)

            prefs.edit {
                putString(ContextKeys.KEY_USER_DATA, json)
            }
        }

        Log.d("ROSS_DEBUG", "saving is complete")
    }

    fun loadUser(): UserBaseModel? {
        synchronized(lock) {
            if (currentUser != null) return currentUser

            val prefs = ContextManager.getContext()
                .getSharedPreferences(ContextKeys.PREFS_NAME, MODE_PRIVATE)

            val json = prefs.getString(ContextKeys.KEY_USER_DATA, null) ?: return null

            currentUser = try {
                UserBaseModel.json.decodeFromString<UserBaseModel>(json)
            } catch (e: Exception) {
                println("Ошибка при загрузке пользователя: ${e.message}")
                null
            }

            return currentUser
        }
    }

    fun isUserExistInContext(): Boolean = currentUser != null

    fun getCurrentUser(): UserBaseModel? = currentUser

    fun logout() {
        synchronized(lock) {
            currentUser = null
            val prefs = ContextManager.getContext()
                .getSharedPreferences(ContextKeys.PREFS_NAME, MODE_PRIVATE)
            prefs.edit { clear() }
        }
    }

    fun getUserRole(): RolesType? = getCurrentUser()?.role

    fun getFullName(): String? {
        val user = getCurrentUser() ?: return null
        return buildString {
            append(user.lastName)
            append(" ")
            append(user.firstName)
            user.middleName?.let {
                append(" ")
                append(it)
            }
        }
    }
}
