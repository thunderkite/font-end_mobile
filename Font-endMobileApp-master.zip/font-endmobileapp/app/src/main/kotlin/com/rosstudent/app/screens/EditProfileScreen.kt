package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
// import com.rosstudent.app.data.UserData -> TODO: на UserManager
// import com.rosstudent.app.data.UserDataStore
import com.rosstudent.app.managers.UserManager
import com.rosstudent.app.models.UserBaseModel
import com.rosstudent.app.navigation.Screen
import com.rosstudent.app.components.CustomTextField
import kotlinx.coroutines.launch

@Composable
fun EditProfileScreen(navController: NavController) {

    Text("надо отрефакторить с использованием UserManager")
    // твой код:
//    val context = LocalContext.current
//    val userDataStore = remember { UserDataStore(context) }
//    val coroutineScope = rememberCoroutineScope()
//
//    // Загружаем данные пользователя
//    var userData by remember { mutableStateOf<UserData?>(null) }
//
//    LaunchedEffect(key1 = true) {
//        userData = userDataStore.getUserData()
//    }
//
//    var firstName by remember { mutableStateOf("") }
//    var lastName by remember { mutableStateOf("") }
//    var middleName by remember { mutableStateOf("") }
//    var email by remember { mutableStateOf("") }
//    var group by remember { mutableStateOf("") }
//
//    // Обновляем поля ввода при загрузке данных пользователя
//    LaunchedEffect(userData) {
//        userData?.let {
//            firstName = it.firstName
//            lastName = it.lastName
//            middleName = it.middleName ?: ""
//            email = it.email
//            group = it.group ?: ""
//        }
//    }
//
//    // Функция сохранения данных
//    fun saveUserData() {
//        userData?.let { user ->
//            val updatedUser = user.copy(
//                firstName = firstName,
//                lastName = lastName,
//                middleName = if (middleName.isNotBlank()) middleName else null,
//                email = email,
//                group = if (group.isNotBlank()) group else null
//            )
//            coroutineScope.launch {
//                userDataStore.saveUserData(updatedUser)
//                navController.navigateUp()
//            }
//        }
//    }
//
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color.White)
//    ) {
//        // Верхняя панель
//        TopAppBar(
//            title = {
//                Text(
//                    text = stringResource(R.string.edit_profile),
//                    fontSize = 20.sp,
//                    fontWeight = FontWeight.Medium
//                )
//            },
//            navigationIcon = {
//                IconButton(onClick = { navController.navigateUp() }) {
//                    Icon(
//                        imageVector = Icons.Default.ArrowBack,
//                        contentDescription = "Back"
//                    )
//                }
//            },
//            actions = {
//                // Добавляем кнопку сохранения
//                TextButton(onClick = { saveUserData() }) {
//                    Text(
//                        text = stringResource(R.string.save),
//                        color = Color(0xFFE94F09),
//                        fontWeight = FontWeight.Medium
//                    )
//                }
//            },
//            colors = TopAppBarDefaults.topAppBarColors(
//                containerColor = Color.White
//            )
//        )
//
//        Column(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(16.dp)
//                .padding(top = 24.dp)
//            ,
//            verticalArrangement = Arrangement.spacedBy(16.dp)
//        ) {
//            // Фото профиля
//            Box(
//                modifier = Modifier
//                    .size(100.dp)
//                    .align(Alignment.CenterHorizontally)
//            ) {
//                Image(
//                    painter = painterResource(id = R.drawable.person_228),
//                    contentDescription = null,
//                    modifier = Modifier.fillMaxSize()
//                )
//                Box(
//                    modifier = Modifier
//                        .align(Alignment.BottomEnd)
//                        .background(Color(0xFFE94F09), shape = RoundedCornerShape(4.dp))
//                        .padding(4.dp)
//                ) {
//                    Icon(
//                        painter = painterResource(id = R.drawable.ic_camera),
//                        contentDescription = "Change",
//                        tint = Color.White,
//                        modifier = Modifier.size(16.dp)
//                    )
//                }
//            }
//
//            // Поля ввода
//            CustomTextField(
//                value = firstName,
//                onValueChange = { firstName = it },
//                placeholderText = stringResource(R.string.firstname),
//                modifier = Modifier.fillMaxWidth()
//            )
//
//            CustomTextField(
//                value = lastName,
//                onValueChange = { lastName = it },
//                placeholderText = stringResource(R.string.surname),
//                modifier = Modifier.fillMaxWidth()
//            )
//
//            CustomTextField(
//                value = middleName,
//                onValueChange = { middleName = it },
//                placeholderText = stringResource(R.string.patronymic),
//                modifier = Modifier.fillMaxWidth()
//            )
//
//            CustomTextField(
//                value = email,
//                onValueChange = { email = it },
//                placeholderText = "email",
//                modifier = Modifier.fillMaxWidth()
//            )
//
//            CustomTextField(
//                value = group,
//                onValueChange = { group = it },
//                placeholderText = stringResource(R.string.group),
//                modifier = Modifier.fillMaxWidth()
//            )
//
//            // Кнопка изменения пароля
//            TextButton(
//                onClick = { navController.navigate(Screen.ChangePassword.route) },
//                modifier = Modifier.align(Alignment.Start)
//            ) {
//                Text(
//                    text = stringResource(R.string.change_password),
//                    color = Color(0xFFE94F09),
//                    fontSize = 16.sp
//                )
//            }
//
//            Spacer(modifier = Modifier.weight(1f))
//
//            // Кнопка выхода из аккаунта
//            TextButton(
//                onClick = {
//                    userDataStore.clearUserData()
//                    navController.navigate(Screen.Auth.route) {
//                        popUpTo(navController.graph.id) {
//                            inclusive = true
//                        }
//                    }
//                },
//                modifier = Modifier.align(Alignment.CenterHorizontally)
//            ) {
//                Text(
//                    text = stringResource(R.string.log_out_of_your_account),
//                    color = Color(0xFFE94F09),
//                    fontSize = 16.sp
//                )
//            }
//        }
//    }
} 