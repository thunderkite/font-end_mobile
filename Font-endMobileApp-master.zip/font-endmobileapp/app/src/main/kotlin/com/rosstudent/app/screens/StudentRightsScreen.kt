package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.navigation.Screen
import androidx.compose.runtime.*
import androidx.annotation.DrawableRes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentRightsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.students_rights),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )
                }
            )
        },
        bottomBar = {
            // Нижняя навигация (островок стиль)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Иконки навигации
                        Image(
                            painter = painterResource(id = R.drawable.home_high),
                            contentDescription = "Main",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Main.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_document),
                            contentDescription = "Documents",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Tasks.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_gift),
                            contentDescription = "Gifts",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Gifts.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_menu),
                            contentDescription = "List",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Schedule.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.reaccount),
                            contentDescription = "More",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.More.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        // Содержимое страницы "Права студентов"
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ClickableChangingImage(
                initialImageResId = R.drawable.question,
                clickedImageResId = R.drawable.question_2,
                contentDescription = "Question Image 1",
                modifier = Modifier.fillMaxWidth()
            )
            ClickableChangingImage(
                initialImageResId = R.drawable.question,
                clickedImageResId = R.drawable.question_2,
                contentDescription = "Question Image 2",
                modifier = Modifier.fillMaxWidth()
            )
            ClickableChangingImage(
                initialImageResId = R.drawable.question,
                clickedImageResId = R.drawable.question_2,
                contentDescription = "Question Image 3",
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ClickableChangingImage(
    @DrawableRes initialImageResId: Int,
    @DrawableRes clickedImageResId: Int,
    contentDescription: String?,
    modifier: Modifier = Modifier
) {
    var isClicked by remember { mutableStateOf(false) }
    val imageResource = if (isClicked) clickedImageResId else initialImageResId

    Image(
        painter = painterResource(id = imageResource),
        contentDescription = contentDescription,
        modifier = modifier.clickable {
            isClicked = !isClicked
        }
    )
} 