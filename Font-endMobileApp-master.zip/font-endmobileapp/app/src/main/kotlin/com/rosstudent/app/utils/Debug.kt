package com.rosstudent.app.utils

import android.util.Log

/**
* Класс дебаг для простой работы
 * ROSS_DEBUG в консольке, чтобы найти лог
 * @sample Debug.log("сообщение")
 */
object Debug {
    fun log(message: String) {
        Log.d("ROSS_DEBUG", message)
    }
}