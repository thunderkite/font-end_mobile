package com.rosstudent.app.validators

class StringMinMaxValidator(
    private val minLength: Int? = null,
    private val maxLength: Int? = null,
    private val allowBlank: Boolean = false
) : Validator<String> {
    override fun validate(value: String): ValidationResult {
        if (value.isBlank() && !allowBlank) {
            return ValidationResult.Error("Поле не может быть пустым")
        }

        minLength?.let {
            if (value.length < it) return ValidationResult.Error("Минимум $it символов")
        }

        maxLength?.let {
            if (value.length > it) return ValidationResult.Error("Максимум $it символов")
        }

        return ValidationResult.Success
    }
}