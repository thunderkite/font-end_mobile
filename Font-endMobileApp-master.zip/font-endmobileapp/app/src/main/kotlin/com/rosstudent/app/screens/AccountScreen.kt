package com.rosstudent.app.screens

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.navigation.Screen
import com.rosstudent.app.enums.RolesType
import com.rosstudent.app.managers.UserManager
import com.rosstudent.app.components.ProfileMenuButtonComponent

@Composable
fun AccountScreen(navController: NavController, isHeadman: Boolean = false) {

    val user = UserManager.getCurrentUser()
    
    Scaffold(
        topBar = { /* Верхняя панель уже встроена в контент, оставим Scaffold без topBar */ },
        bottomBar = {
            // Нижняя навигация (островок стиль)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Иконки навигации
                        Image(
                            painter = painterResource(id = R.drawable.home_high),
                            contentDescription = "Main",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Main.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_document),
                            contentDescription = "Documents",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Tasks.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_gift),
                            contentDescription = "Gifts",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Gifts.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_menu),
                            contentDescription = "List",
                            modifier = Modifier.size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Schedule.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.reaccount_orange),
                            contentDescription = "More",
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color.White)
                .padding(16.dp)
                .padding(top = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Заголовок по центру
            Text(
                text = stringResource(R.string.my_profile),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
            )
            // Профильная строка
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Аватар
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE0E0E0)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.person_228),
                        contentDescription = null,
                        modifier = Modifier.size(76.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                // Имя и группа
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = if (user != null) {
                            "${user.lastName} ${user.firstName} ${user.middleName ?: ""}".trim()
                        } else {
                            stringResource(R.string.loading)
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "Тут должна быть группа", // TODO: Поправить как определимся с типами
                        color = Color(0xFFBDBDBD),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
            // Кнопки редактирования и настроек
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { navController.navigate(Screen.EditProfile.route) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(44.dp)
                ) {
                    Text(
                        text = stringResource(R.string.change_profile),
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0xFFF5F5F5), shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_settings_3),
                        contentDescription = null,
                        tint = Color(0xFFBDBDBD),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
            // Кнопки-меню профиля
            var selectedMenuIndex by remember { mutableStateOf(-1) }
            val menuItems = buildList {
                add(Triple(R.drawable.prof_1, stringResource(R.string.notifications)) { /* TODO */ })
                if (user?.role == RolesType.GroupLeader) {
                    add(Triple(R.drawable.prof_2, stringResource(R.string.group_settings)) { navController.navigate("group_list/0") })
                }
                add(Triple(R.drawable.prof_3, stringResource(R.string.support)) { /* TODO */ })
                add(Triple(R.drawable.prof_4, stringResource(R.string.frequently_asked_questions)) { /* TODO */ })
                add(Triple(R.drawable.prof_4, stringResource(R.string.opportunities_and_benefits)) { /* TODO */ })
                add(Triple(R.drawable.prof_4, stringResource(R.string.about_the_app_developers)) { /* TODO */ })
            }
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                menuItems.forEachIndexed { index, item ->
                    ProfileMenuButtonComponent(
                        icon = item.first,
                        text = item.second,
                        onClick = {
                            selectedMenuIndex = index
                            item.third()
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            TextButton(
                onClick = { UserManager.logout() },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text(
                    text = stringResource(R.string.log_out_of_your_account),
                    color = Color(0xFFE94F09),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

