package com.rosstudent.app.models

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@kotlinx.serialization.InternalSerializationApi
@Serializable
@SerialName("LocalContext")
data class LocalContextModel(
    @SerialName("login")
    val login: String,
    @SerialName("password")
    val password: String,
)
