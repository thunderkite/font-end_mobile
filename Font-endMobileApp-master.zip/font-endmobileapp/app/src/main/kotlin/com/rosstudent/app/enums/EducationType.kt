package com.rosstudent.app.enums


import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
enum class EducationType {
    @SerialName("Institute")
    Institute,
    @SerialName("College")
    College
}