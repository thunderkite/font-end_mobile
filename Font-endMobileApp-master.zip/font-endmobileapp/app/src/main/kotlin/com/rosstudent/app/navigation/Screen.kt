package com.rosstudent.app.navigation

sealed class Screen(val route: String) {
    object Auth : Screen(route = "auth_screen")
    object Registration : Screen(route = "registration_screen")
    object ForgotPassword : Screen(route = "forgot_password_screen")
    object Main : Screen(route = "main_screen")
    object OpportunitiesAndBenefits : Screen(route = "opportunities_and_benefits_screen")
    object YouthRights : Screen(route = "youth_rights_screen")
    object StudentRights : Screen(route = "student_rights_screen")
    object Account : Screen(route = "account_screen")
    object Home : Screen(route = "home_screen")
    object Tasks : Screen(route = "tasks_screen")
    object Schedule : Screen(route = "schedule_screen")
    object GroupList : Screen(route = "group_list_screen")
    object Gifts : Screen(route = "gifts_screen")
    object EditProfile : Screen(route = "edit_profile_screen")
    object ChangePassword : Screen(route = "change_password_screen")
    object EmailConfirmation : Screen(route = "email_confirmation_screen")
    object ForgotPasswordEmail : Screen("forgot_password_email_screen")
    object ForgotPasswordCode : Screen("forgot_password_code_screen")
    object ForgotPasswordNewPassword : Screen("forgot_password_new_password_screen")
    object ForgotPasswordSuccess : Screen("forgot_password_success_screen")
    object Welcome : Screen("welcome_screen")
    object More : Screen("more_screen")
    object CreateTask : Screen("create_task")
    object TaskDetails : Screen("task_details/{taskId}") {
        fun createRoute(taskId: String) = "task_details/$taskId"
    }
    object TaskAnswers : Screen("task_answers/{taskId}") {
        fun createRoute(taskId: String) = "task_answers/$taskId"
    }
} 