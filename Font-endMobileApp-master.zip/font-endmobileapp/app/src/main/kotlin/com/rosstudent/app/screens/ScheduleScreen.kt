package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.navigation.Screen
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.*
import android.util.Log

data class Lesson(
    val id: String,
    val number: Int,
    val name: String,
    val startTime: String,
    val endTime: String,
    val room: String
)

@Composable
fun ScheduleScreen(
    navController: NavController,
    isHeadman: Boolean = false // По умолчанию false - обычный студент
) {
//    val context = LocalContext.current
//    val userDataStore = remember { ContextController(context) }
//    // При загрузке экрана, проверяем актуальную роль пользователя
//    val currentIsHeadman = userDataStore.isHeadman()
//
//    Log.d("ScheduleScreen", "isHeadman parameter: $isHeadman, current value from store: $currentIsHeadman")
//
//    // Используем актуальное значение из хранилища, игнорируя переданное извне
//    val effectiveIsHeadman = currentIsHeadman
//
//    val currentDate = LocalDate.now()
//    val currentWeekMonday = currentDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
//    val weekDays = (0..6).map { currentWeekMonday.plusDays(it.toLong()) }
//
//    var selectedDate by remember { mutableStateOf(currentDate) }
//
//    val lessons = remember {
//        listOf(
//            Lesson("1", 1, "Высшая математика", "8:00", "9:30", "ауд. 211 к.1"),
//            Lesson("2", 2, "История России", "9:40", "11:10", "ауд. 315 к.3"),
//            Lesson("3", 3, "Теоритическая маханика", "11:20", "12:50", "ауд. 411 к.2"),
//            Lesson("4", 4, "Сопротивление материалов", "13:30", "14:50", "ауд. 414 к.2"),
//            Lesson("5", 5, "Социология", "15:00", "16:30", "ауд. 323 к.5"),
//            Lesson("6", 6, "Философия", "16:45", "18:15", "ауд. 344 к.5")
//        )
//    }
//
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color.White)
//            .padding(top = 24.dp)
//    ) {
//        // Календарь
//        Row(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(horizontal = 8.dp, vertical = 12.dp),
//            horizontalArrangement = Arrangement.SpaceBetween
//        ) {
//            weekDays.forEach { date ->
//                Box(
//                    modifier = Modifier
//                        .weight(1f)
//                        .padding(horizontal = 2.dp)
//                ) {
//                    DayItem(
//                        date = date,
//                        isSelected = date == selectedDate,
//                        selectedDate = selectedDate,
//                        onClick = { selectedDate = date }
//                    )
//                }
//            }
//        }
//
//        // Список занятий
//        LazyColumn(
//            modifier = Modifier
//                .weight(1f)
//                .padding(horizontal = 16.dp),
//            verticalArrangement = Arrangement.spacedBy(8.dp)
//        ) {
//            items(lessons) { lesson ->
//                LessonCard(
//                    lesson = lesson,
//                    isHeadman = effectiveIsHeadman,
//                    onClick = {
//                        if (effectiveIsHeadman) {
//                            navController.navigate("group_list/${lesson.id}")
//                        }
//                    }
//                )
//            }
//        }
//
//        // Нижняя навигация
//        Box(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(horizontal = 10.dp, vertical = 8.dp)
//        ) {
//            Card(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(56.dp),
//                shape = RoundedCornerShape(28.dp),
//                colors = CardDefaults.cardColors(containerColor = Color.White)
//            ) {
//                Row(
//                    modifier = Modifier
//                        .fillMaxSize()
//                        .padding(horizontal = 24.dp),
//                    horizontalArrangement = Arrangement.SpaceBetween,
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Image(
//                        painter = painterResource(id = R.drawable.home_high),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.Main.route)
//                            }
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.ic_document),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.Tasks.route)
//                            }
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.ic_gift),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.Gifts.route)
//                            }
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.menu_orange_high),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.Schedule.route)
//                            }
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.reaccount),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.More.route)
//                            }
//                    )
//                }
//            }
//        }
//    }
//}
//
//@Composable
//fun DayItem(
//    date: LocalDate,
//    isSelected: Boolean,
//    selectedDate: LocalDate,
//    onClick: () -> Unit
//) {
//    val dayOfWeek = date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("ru"))
//    val isToday = date == LocalDate.now()
//    val month = date.month.getDisplayName(TextStyle.FULL, Locale("ru"))
//
//    Card(
//        modifier = Modifier
//            .fillMaxWidth()
//            .height(80.dp)
//            .clip(RoundedCornerShape(8.dp))
//            .clickable(onClick = onClick)
//            .background(if (isSelected) Color(0xFFE94F09) else Color.Transparent),
//        colors = CardDefaults.cardColors(
//            containerColor = if (isSelected) Color(0xFFE94F09) else Color.White
//        ),
//        elevation = CardDefaults.cardElevation(
//            defaultElevation = if (isSelected) 4.dp else 1.dp
//        )
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(4.dp),
//            horizontalAlignment = Alignment.CenterHorizontally,
//            verticalArrangement = Arrangement.Center
//        ) {
//            Text(
//                text = dayOfWeek.uppercase(),
//                fontSize = 11.sp,
//                color = if (isSelected) Color.White else Color.Gray
//            )
//            Text(
//                text = date.dayOfMonth.toString(),
//                fontSize = 16.sp,
//                fontWeight = FontWeight.Bold,
//                color = if (isSelected) Color.White else Color.Black
//            )
//            if (isToday || date.dayOfMonth == 1 || (date == selectedDate)) {
//                Text(
//                    text = month,
//                    fontSize = 10.sp,
//                    color = if (isSelected) Color.White else Color(0xFFE94F09)
//                )
//            }
//        }
//    }
//}
//
//@Composable
//fun LessonCard(
//    lesson: Lesson,
//    isHeadman: Boolean,
//    onClick: () -> Unit
//) {
//    Card(
//        modifier = Modifier
//            .fillMaxWidth()
//            .then(
//                if (isHeadman) {
//                    Modifier.clickable(onClick = onClick)
//                } else {
//                    Modifier
//                }
//            ),
//        shape = RoundedCornerShape(8.dp),
//        colors = CardDefaults.cardColors(containerColor = Color.White),
//        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(16.dp)
//        ) {
//            Row(
//                modifier = Modifier.fillMaxWidth(),
//                horizontalArrangement = Arrangement.SpaceBetween,
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                Text(
//                    text = "${lesson.number} занятие",
//                    fontSize = 12.sp,
//                    color = Color.Gray
//                )
//                Row(
//                    horizontalArrangement = Arrangement.spacedBy(8.dp),
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    if (isHeadman) {
//                        Text(
//                            text = stringResource(R.string.notice),
//                            fontSize = 12.sp,
//                            color = Color(0xFFE94F09),
//                            modifier = Modifier.clickable(onClick = onClick)
//                        )
//                    }
//                    Text(
//                        text = "${lesson.startTime} - ${lesson.endTime}",
//                        fontSize = 12.sp,
//                        color = Color(0xFFE94F09)
//                    )
//                }
//            }
//            Text(
//                text = lesson.name,
//                fontSize = 16.sp,
//                fontWeight = FontWeight.Medium,
//                modifier = Modifier.padding(vertical = 4.dp)
//            )
//            Text(
//                text = lesson.room,
//                fontSize = 12.sp,
//                color = Color.Gray
//            )
//        }
//    }
} 