package com.rosstudent.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.data.Question
import com.rosstudent.app.data.Task
import com.rosstudent.app.data.TaskPriority
import com.rosstudent.app.data.TaskStore
import com.rosstudent.app.data.TaskType
import com.rosstudent.app.managers.UserManager
import com.rosstudent.app.navigation.Screen
import kotlinx.coroutines.launch
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateTaskScreenWithQuestions(
    navController: NavController
) {
    val context = LocalContext.current
    val taskStore = remember { TaskStore(context) }
    val userData = UserManager.getCurrentUser()
    val coroutineScope = rememberCoroutineScope()
    
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var deadline by remember { mutableStateOf("") }
    var selectedTypeId by remember { mutableStateOf("3") } // По умолчанию задача от старосты
    var selectedPriorityId by remember { mutableStateOf("1") } // По умолчанию обычный приоритет
    
    // Переключатели для различных опций
    var notifyEveryone by remember { mutableStateOf(false) }
    var sendToDepartment by remember { mutableStateOf(true) } // По умолчанию активно на скриншоте 1
    var sendToEducational by remember { mutableStateOf(false) }
    var collectInformation by remember { mutableStateOf(false) } // На втором скриншоте активно
    
    // Список вопросов для задачи (только если включен сбор информации)
    var questions by remember { mutableStateOf(listOf(
        Question(
            questionId = UUID.randomUUID().toString(),
            taskId = "",
            questionText = "Вопрос 1",
            questionType = "TEXT",
            required = true
        )
    )) }
    
    // Варианты ответов для вопросов с выбором
    var questionOptions by remember { mutableStateOf(mapOf<String, List<String>>()) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = stringResource(R.string.tasks),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF5F5F5))
                .verticalScroll(rememberScrollState())
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Text(
                    text = stringResource(R.string.add_task),
                    fontSize = 16.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }
            
            // Название задачи
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.task_name),
                        color = Color(0xFFE94F09),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    
                    Text(
                        text = stringResource(R.string.enter_the_task_name),
                        color = Color.Gray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
            OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        placeholder = { Text("") },
                modifier = Modifier
                    .fillMaxWidth()
                            .height(56.dp),
                shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                            unfocusedContainerColor = Color(0xFFF5F5F5),
                            focusedContainerColor = Color(0xFFF5F5F5)
                        )
                    )
                }
            }
            
            // Описание задачи
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = stringResource(R.string.task_description),
                        color = Color(0xFFE94F09),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    
                    Text(
                        text = stringResource(R.string.enter_the_task_description),
                        color = Color.Gray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        placeholder = { Text("") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                            unfocusedContainerColor = Color(0xFFF5F5F5),
                            focusedContainerColor = Color(0xFFF5F5F5)
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Переключатели
                    SwitchRow(
                        text = stringResource(R.string.notify_everyone),
                        checked = notifyEveryone,
                        onCheckedChange = { notifyEveryone = it }
                    )
                    
                    SwitchRow(
                        text = stringResource(R.string.transfer_to_the_departaments_management),
                        checked = sendToDepartment,
                        onCheckedChange = { sendToDepartment = it }
                    )
                    
                    SwitchRow(
                        text = stringResource(R.string.transfer_to_the_management_of_the_educational_institution),
                        checked = sendToEducational,
                        onCheckedChange = { sendToEducational = it }
                    )
                    
                    SwitchRow(
                        text = stringResource(R.string.collect_information),
                        checked = collectInformation,
                        onCheckedChange = { collectInformation = it }
                    )
                }
            }
            
            // Выбор получателей
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.select_recipients),
                        fontSize = 16.sp
                    )
                    
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowRight,
                        contentDescription = "Select",
                        tint = Color.Gray
                    )
                }
            }
            
            // Срок выполнения
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.task_completion_dates),
                        fontSize = 16.sp
                    )
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.date),
                            color = Color(0xFFE94F09),
                            fontSize = 14.sp,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        
                Icon(
                            painter = painterResource(id = R.drawable.ic_calendar),
                            contentDescription = stringResource(R.string.select_a_date),
                            tint = Color(0xFFE94F09),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
            
            // Секция вопросов (только если включен сбор информации)
            if (collectInformation) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Text(
                        text = stringResource(R.string.add_a_question),
                        fontSize = 16.sp,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
            
            // Кнопка создания задачи
            Button(
                onClick = {
                    // Проверка заполнения обязательных полей
                    if (description.isBlank()) {
                        // Показать сообщение об ошибке
                        return@Button
                    }
                    
                    userData?.let { user ->
                        // Создаем задачу
                        val taskId = UUID.randomUUID().toString()
                        val task = Task(
                            id = taskId,
                            title = if (title.isBlank()) "Новая задача" else title,
                            description = description,
                            type = getTaskTypeById(selectedTypeId) ?: TaskType.HEADMAN,
                            priority = getPriorityById(selectedPriorityId) ?: TaskPriority.NORMAL,
                            deadline = if (deadline.isBlank()) "Без срока" else deadline,
                            createdBy = user.userId,
                            createdAt = System.currentTimeMillis(),
                            groupId = "Тут должна быть группа" // TODO поправить группы
                        )
                        
                        coroutineScope.launch {
                            // Сохраняем задачу
                            taskStore.addTask(task)
                            
                            // Сохраняем вопросы, если включен сбор информации
                            if (collectInformation) {
                            for (question in questions) {
                                val updatedQuestion = question.copy(taskId = taskId)
                                val questionId = taskStore.addQuestion(updatedQuestion)
                                
                                // Если у вопроса есть варианты ответов, сохраняем их
                                val options = questionOptions[question.questionId]
                                if (!options.isNullOrEmpty() && 
                                    (question.questionType == "MULTIPLE_CHOICE" || 
                                     question.questionType == "DROPDOWN")) {
                                    taskStore.addOptionsForQuestion(questionId, options)
                                    }
                                }
                            }
                            
                            // Возвращаемся к списку задач
                            navController.navigate(Screen.Tasks.route)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09))
            ) {
                Text(
                    text = stringResource(R.string.upload_task),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// Получить приоритет по ID
private fun getPriorityById(priorityId: String): TaskPriority? {
    return when(priorityId) {
        "1" -> TaskPriority.NORMAL
        "2" -> TaskPriority.URGENT
        "3" -> TaskPriority.ARCHIVED
        else -> null
    }
}

// Получить тип задачи по ID
private fun getTaskTypeById(typeId: String): TaskType? {
    return when(typeId) {
        "1" -> TaskType.FEDERAL
        "2" -> TaskType.EDUCATIONAL
        "3" -> TaskType.HEADMAN
        else -> null
    }
}

@Composable
private fun SwitchRow(
    text: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            fontSize = 14.sp,
            color = if (checked) Color(0xFFE94F09) else Color.Gray
        )
        
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.scale(0.8f),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFFE94F09),
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color.LightGray
            )
        )
    }
}

// Расширение для изменения размера компонента
fun Modifier.scale(scale: Float) = this.then(
    Modifier.size(
        width = (34 * scale).dp,  // Примерная ширина стандартного Switch
        height = (20 * scale).dp   // Примерная высота стандартного Switch
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuestionCard(
    question: Question,
    options: List<String>,
    onQuestionChange: (Question) -> Unit,
    onOptionsChange: (List<String>) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Текст вопроса
            OutlinedTextField(
                value = question.questionText,
                onValueChange = { 
                    onQuestionChange(question.copy(questionText = it))
                },
                label = { Text(stringResource(R.string.question_text)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                shape = RoundedCornerShape(8.dp),
                singleLine = true
            )
            
            // Тип вопроса
            var expandedTypeMenu by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = expandedTypeMenu,
                onExpandedChange = { expandedTypeMenu = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                OutlinedTextField(
                    value = when (question.questionType) {
                        "TEXT" -> stringResource(R.string.text_response)
                        "FILE" -> stringResource(R.string.file_response)
                        "MULTIPLE_CHOICE" -> stringResource(R.string.multiple_response)
                        "DROPDOWN" -> stringResource(R.string.drop_down_list)
                        else -> stringResource(R.string.select_the_type_of_question)
                    },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(stringResource(R.string.question_type)) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedTypeMenu) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
                ExposedDropdownMenu(
                    expanded = expandedTypeMenu,
                    onDismissRequest = { expandedTypeMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.text_response)) },
                        onClick = {
                            onQuestionChange(question.copy(questionType = "TEXT"))
                            expandedTypeMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.file_response)) },
                        onClick = {
                            onQuestionChange(question.copy(questionType = "FILE"))
                            expandedTypeMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.multiple_response)) },
                        onClick = {
                            onQuestionChange(question.copy(questionType = "MULTIPLE_CHOICE"))
                            expandedTypeMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.drop_down_list)) },
                        onClick = {
                            onQuestionChange(question.copy(questionType = "DROPDOWN"))
                            expandedTypeMenu = false
                        }
                    )
                }
            }
            
            // Варианты ответов для вопросов с выбором
            if (question.questionType == "MULTIPLE_CHOICE" || question.questionType == "DROPDOWN") {
                Text(
                    text = stringResource(R.string.answer_option),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
                
                val currentOptions = options.ifEmpty { listOf("") }
                
                for (index in currentOptions.indices) {
                    val option = currentOptions[index]
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 4.dp)
                    ) {
                        OutlinedTextField(
                            value = option,
                            onValueChange = { 
                                val updatedOptions = currentOptions.toMutableList()
                                updatedOptions[index] = it
                                onOptionsChange(updatedOptions)
                            },
                            label = { Text("${stringResource(R.string.option)} ${index + 1}") },
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true
                        )
                        
                        if (currentOptions.size > 1) {
                            IconButton(
                                onClick = {
                                    val updatedOptions = currentOptions.filterIndexed { i, _ -> i != index }
                                    onOptionsChange(updatedOptions)
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "delete an option",
                                    tint = Color.Gray
                                )
                            }
                        }
                    }
                }
                
                // Кнопка добавления варианта
                TextButton(
                    onClick = {
                        onOptionsChange(currentOptions + "")
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.add_an_option))
                }
            }
            
            // Переключатель "Обязательный вопрос"
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { onDelete() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "delete the question",
                            tint = Color.Gray
                        )
                    }
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.mandatory_question),
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                    Switch(
                        checked = question.required,
                        onCheckedChange = { 
                            onQuestionChange(question.copy(required = it))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFFE94F09),
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = Color.LightGray
                        )
                    )
                }
            }
        }
    }
} 