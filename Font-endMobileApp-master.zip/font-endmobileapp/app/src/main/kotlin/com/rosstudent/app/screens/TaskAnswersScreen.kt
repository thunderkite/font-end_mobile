package com.rosstudent.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.data.Answer
import com.rosstudent.app.data.Question
import com.rosstudent.app.data.QuestionOption
import com.rosstudent.app.data.Task
import com.rosstudent.app.data.TaskStore
import com.rosstudent.app.data.TaskType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskAnswersScreen(
    taskId: String,
    navController: NavController
) {
//    val context = LocalContext.current
//    val taskStore = remember { TaskStore(context) }
//    val userDataStore = remember { ContextController(context) }
//    val userData = userDataStore.getUserData()
//
//    var task by remember { mutableStateOf<Task?>(null) }
//    var questions by remember { mutableStateOf<List<Question>>(emptyList()) }
//    var answers by remember { mutableStateOf<Map<String, Answer>>(emptyMap()) }
//    var questionOptions by remember { mutableStateOf<Map<String, List<QuestionOption>>>(emptyMap()) }
//    var selectedOptions by remember { mutableStateOf<Map<String, List<String>>>(emptyMap()) }
//
//    // Загружаем данные задачи, вопросы и ответы
//    LaunchedEffect(taskId) {
//        // Находим задачу по ID
//        task = taskStore.getAllTasks().find { it.id == taskId }
//
//        // Загружаем вопросы для задачи
//        questions = taskStore.getQuestionsForTask(taskId)
//
//        // Загружаем ответы пользователя
//        userData?.let { user ->
//            answers = taskStore.getUserAnswersForTask(user.userId, taskId)
//
//            // Загружаем выбранные варианты для каждого ответа
//            val selected = mutableMapOf<String, List<String>>()
//            answers.forEach { (questionId, answer) ->
//                selected[questionId] = taskStore.getSelectedOptionsForAnswer(answer.answerId)
//            }
//            selectedOptions = selected
//        }
//
//        // Загружаем варианты ответов для каждого вопроса
//        val options = mutableMapOf<String, List<QuestionOption>>()
//        questions.forEach { question ->
//            options[question.questionId] = taskStore.getOptionsForQuestion(question.questionId)
//        }
//        questionOptions = options
//    }
//
//    Scaffold(
//        topBar = {
//            TopAppBar(
//                title = {
//                    Text(
//                        text = "Мои ответы",
//                        fontSize = 20.sp,
//                        fontWeight = FontWeight.Bold
//                    )
//                },
//                navigationIcon = {
//                    IconButton(onClick = { navController.popBackStack() }) {
//                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
//                    }
//                },
//                colors = TopAppBarDefaults.topAppBarColors(
//                    containerColor = Color.White
//                )
//            )
//        }
//    ) { paddingValues ->
//        Box(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(paddingValues)
//                .background(Color.White)
//        ) {
//            if (task != null) {
//                Column(
//                    modifier = Modifier
//                        .fillMaxSize()
//                        .padding(16.dp)
//                        .verticalScroll(rememberScrollState()),
//                    horizontalAlignment = Alignment.CenterHorizontally
//                ) {
//                    // Информация о задаче
//                    Card(
//                        modifier = Modifier
//                            .fillMaxWidth()
//                            .padding(bottom = 16.dp),
//                        shape = RoundedCornerShape(16.dp),
//                        colors = CardDefaults.cardColors(
//                            containerColor = when (task!!.type) {
//                                TaskType.FEDERAL -> Color(0xFFE3F2FD) // Голубой для федеральных
//                                TaskType.EDUCATIONAL -> Color(0xFFE8F5E9) // Зеленый для учебных
//                                TaskType.HEADMAN -> Color(0xFFFFF3E0) // Персиковый для задач от старосты
//                                else -> Color(0xFFEEEEEE) // Серый для неизвестных
//                            }
//                        )
//                    ) {
//                        Column(
//                            modifier = Modifier.padding(16.dp)
//                        ) {
//                            Text(
//                                text = task!!.title,
//                                fontSize = 20.sp,
//                                fontWeight = FontWeight.Bold,
//                                modifier = Modifier.padding(bottom = 8.dp)
//                            )
//                            Text(
//                                text = "Срок выполнения: ${task!!.deadline}", //TODO: поправить
//                                fontSize = 14.sp,
//                                color = Color.Gray,
//                                modifier = Modifier.padding(bottom = 8.dp)
//                            )
//                            Text(
//                                text = task!!.description,
//                                fontSize = 16.sp,
//                                modifier = Modifier.padding(bottom = 8.dp)
//                            )
//                            Card(
//                                shape = RoundedCornerShape(12.dp),
//                                colors = CardDefaults.cardColors(containerColor = Color(0xFF4CAF50)),
//                                modifier = Modifier.align(Alignment.End)
//                            ) {
//                                Text(
//                                    text = stringResource(R.string.done),
//                                    color = Color.White,
//                                    fontSize = 14.sp,
//                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
//                                )
//                            }
//                        }
//                    }
//
//                    // Заголовок раздела ответов
//                    Text(
//                        text = stringResource(R.string.my_answers_to_the_questions),
//                        fontSize = 18.sp,
//                        fontWeight = FontWeight.Bold,
//                        modifier = Modifier
//                            .fillMaxWidth()
//                            .padding(vertical = 12.dp),
//                        textAlign = TextAlign.Center
//                    )
//
//                    // Отображаем вопросы и ответы
//                    questions.forEach { question ->
//                        val answer = answers[question.questionId]
//
//                        Card(
//                            modifier = Modifier
//                                .fillMaxWidth()
//                                .padding(vertical = 8.dp),
//                            shape = RoundedCornerShape(12.dp),
//                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
//                        ) {
//                            Column(
//                                modifier = Modifier.padding(16.dp)
//                            ) {
//                                // Вопрос
//                                Text(
//                                    text = question.questionText,
//                                    fontWeight = FontWeight.Bold,
//                                    fontSize = 16.sp,
//                                    modifier = Modifier.padding(bottom = 8.dp)
//                                )
//
//                                // Ответ
//                                when (question.questionType) {
//                                    "TEXT" -> {
//                                        if (answer?.textAnswer != null) {
//                                            Card(
//                                                modifier = Modifier
//                                                    .fillMaxWidth()
//                                                    .padding(top = 4.dp),
//                                                shape = RoundedCornerShape(8.dp),
//                                                colors = CardDefaults.cardColors(containerColor = Color.White)
//                                            ) {
//                                                Text(
//                                                    text = answer.textAnswer,
//                                                    fontSize = 16.sp,
//                                                    modifier = Modifier.padding(12.dp)
//                                                )
//                                            }
//                                        } else {
//                                            Text(
//                                                text = stringResource(R.string.there_is_no_response),
//                                                color = Color.Gray,
//                                                fontSize = 16.sp,
//                                                modifier = Modifier.padding(top = 4.dp)
//                                            )
//                                        }
//                                    }
//                                    "FILE" -> {
//                                        // Предполагаем, что в модели Answer есть поле fileUrl
//                                        val fileUrl = answer?.textAnswer // Используем textAnswer как fileUrl
//                                        if (fileUrl != null) {
//                                            Card(
//                                                modifier = Modifier
//                                                    .fillMaxWidth()
//                                                    .padding(top = 4.dp),
//                                                shape = RoundedCornerShape(8.dp),
//                                                colors = CardDefaults.cardColors(containerColor = Color.White)
//                                            ) {
//                                                Column(modifier = Modifier.padding(12.dp)) {
//                                                    Text(
//                                                        text = stringResource(R.string.attached_file),
//                                                        fontSize = 14.sp,
//                                                        color = Color.Gray
//                                                    )
//                                                    Text(
//                                                        text = fileUrl,
//                                                        fontSize = 16.sp,
//                                                        color = Color(0xFF2196F3),
//                                                        modifier = Modifier.padding(top = 4.dp)
//                                                    )
//                                                }
//                                            }
//                                        } else {
//                                            Text(
//                                                text = stringResource(R.string.the_file_is_not_attached),
//                                                color = Color.Gray,
//                                                fontSize = 16.sp,
//                                                modifier = Modifier.padding(top = 4.dp)
//                                            )
//                                        }
//                                    }
//                                    "MULTIPLE_CHOICE", "DROPDOWN" -> {
//                                        val selected = selectedOptions[question.questionId] ?: emptyList()
//                                        val options = questionOptions[question.questionId] ?: emptyList()
//
//                                        if (selected.isNotEmpty() && options.isNotEmpty()) {
//                                            val selectedTexts = options
//                                                .filter { option -> selected.contains(option.optionId) }
//                                                .map { it.optionText }
//
//                                            Card(
//                                                modifier = Modifier
//                                                    .fillMaxWidth()
//                                                    .padding(top = 4.dp),
//                                                shape = RoundedCornerShape(8.dp),
//                                                colors = CardDefaults.cardColors(containerColor = Color.White)
//                                            ) {
//                                                Column(modifier = Modifier.padding(12.dp)) {
//                                                    selectedTexts.forEach { selectedText ->
//                                                        Text(
//                                                            text = selectedText,
//                                                            fontSize = 16.sp,
//                                                            modifier = Modifier.padding(vertical = 2.dp)
//                                                        )
//                                                    }
//                                                }
//                                            }
//                                        } else {
//                                            Text(
//                                                text = stringResource(R.string.the_option_is_not_selected),
//                                                color = Color.Gray,
//                                                fontSize = 16.sp,
//                                                modifier = Modifier.padding(top = 4.dp)
//                                            )
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//            } else {
//                // Показываем индикатор загрузки, если задача еще не загружена
//                Box(
//                    modifier = Modifier.fillMaxSize(),
//                    contentAlignment = Alignment.Center
//                ) {
//                    CircularProgressIndicator(
//                        color = Color(0xFF1976D2)
//                    )
//                }
//            }
//        }
//    }
} 