package com.rosstudent.app.models

import com.rosstudent.app.enums.RolesType
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
@SerialName("Guest")
data class GuestUserModel(
    @SerialName("user_id")
    override val userId: String,
    @SerialName("first_name")
    override var firstName: String,
    @SerialName("last_name")
    override var lastName: String,
    @SerialName("email")
    override var email: String,
    @SerialName("middle_name")
    override var middleName: String? = null
) : UserBaseModel() {
    @SerialName("role")
    override val role: RolesType = RolesType.Guest
}