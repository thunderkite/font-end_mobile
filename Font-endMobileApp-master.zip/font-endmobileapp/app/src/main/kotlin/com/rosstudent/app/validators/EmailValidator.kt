package com.rosstudent.app.validators

import android.util.Patterns

class EmailValidator : Validator<String> {
    override fun validate(value: String): ValidationResult {
        return when {
            value.isBlank() -> ValidationResult.Error("Email не может быть пустым") // TODO: локализовать
            !Patterns.EMAIL_ADDRESS.matcher(value).matches() ->
                ValidationResult.Error("Некорректный формат email") // TODO: локализовать
            else -> ValidationResult.Success
        }
    }
}