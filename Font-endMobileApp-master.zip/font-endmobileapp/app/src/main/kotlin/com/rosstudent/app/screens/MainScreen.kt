package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rosstudent.app.R
import androidx.navigation.NavController
import com.rosstudent.app.navigation.Screen
import android.util.Log
import androidx.compose.ui.platform.LocalContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(navController: NavController) {
//    // Проверяем роль пользователя
//    val context = LocalContext.current
//    val userDataStore = remember { ContextController(context) }
//    val isHeadman = userDataStore.isHeadman()
//
//    LaunchedEffect(key1 = true) {
//        Log.d("MainScreen", "User is headman: $isHeadman")
//    }
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color(0xFFF5F5F5))
//    ) {
//        // Оранжевый узор внизу слева
//        Image(
//            painter = painterResource(id = R.drawable.frame_2_high),
//            contentDescription = null,
//            modifier = Modifier
//                .align(Alignment.BottomStart)
//                .offset(x = (-50).dp, y = (-30).dp)
//                .size(200.dp),
//            contentScale = ContentScale.Fit
//        )
//
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(horizontal = 16.dp)
//                .padding(top = 24.dp)
//        ) {
//            LazyColumn(
//                modifier = Modifier
//                    .weight(1f)
//                    .padding(bottom = 80.dp)
//            ) {
//                item {
//                    // Горизонтальный прокручиваемый список карточек
//                    LazyRow(
//                        modifier = Modifier.fillMaxWidth(),
//                        horizontalArrangement = Arrangement.spacedBy(8.dp),
//                        contentPadding = PaddingValues(horizontal = 8.dp)
//                    ) {
//                        item {
//                            Card(
//                                modifier = Modifier
//                                    .width(160.dp)
//                                    .aspectRatio(0.70f),
//                                shape = RoundedCornerShape(16.dp)
//                            ) {
//                                Image(
//                                    painter = painterResource(id = R.drawable.family_image),
//                                    contentDescription = "benefits for student families",
//                                    modifier = Modifier.fillMaxSize(),
//                                    contentScale = ContentScale.Crop
//                                )
//                            }
//                        }
//
//                        item {
//                            Card(
//                                modifier = Modifier
//                                    .width(160.dp)
//                                    .aspectRatio(0.70f),
//                                shape = RoundedCornerShape(16.dp)
//                            ) {
//                                Image(
//                                    painter = painterResource(id = R.drawable.student_image),
//                                    contentDescription = "get a useful intership",
//                                    modifier = Modifier.fillMaxSize(),
//                                    contentScale = ContentScale.Crop
//                                )
//                            }
//                        }
//
//                        item {
//                            Card(
//                                modifier = Modifier
//                                    .width(160.dp)
//                                    .aspectRatio(0.70f),
//                                shape = RoundedCornerShape(16.dp)
//                            ) {
//                                Image(
//                                    painter = painterResource(id = R.drawable.education),
//                                    contentDescription = "education",
//                                    modifier = Modifier.fillMaxSize(),
//                                    contentScale = ContentScale.Crop
//                                )
//                            }
//                        }
//
//                        item {
//                            Card(
//                                modifier = Modifier
//                                    .width(160.dp)
//                                    .aspectRatio(0.70f),
//                                shape = RoundedCornerShape(16.dp)
//                            ) {
//                                Image(
//                                    painter = painterResource(id = R.drawable.journey),
//                                    contentDescription = "journeys",
//                                    modifier = Modifier.fillMaxSize(),
//                                    contentScale = ContentScale.Crop
//                                )
//                            }
//                        }
//                    }
//                }
//
//                item {
//                    Spacer(modifier = Modifier.height(16.dp))
//
//                    // Баннер #Росстудент
//                    Card(
//                        modifier = Modifier
//                            .fillMaxWidth()
//                            .height(120.dp),
//                        shape = RoundedCornerShape(16.dp)
//                    ) {
//                        Box(
//                            modifier = Modifier
//                                .fillMaxSize()
//                                .background(Color(0xFFFF5722))
//                        ) {
//                            Image(
//                                painter = painterResource(id = R.drawable.student_practice),
//                                contentDescription = null,
//                                modifier = Modifier.fillMaxSize(),
//                                contentScale = ContentScale.Crop
//                            )
//                        }
//                    }
//                }
//
//                item {
//                    Spacer(modifier = Modifier.height(16.dp))
//
//                    // Нижние карточки
//                    Row(
//                        modifier = Modifier.fillMaxWidth(),
//                        horizontalArrangement = Arrangement.spacedBy(8.dp)
//                    ) {
//                        Image(
//                            painter = painterResource(id = R.drawable.benefits_and_privileges_1),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .weight(1f)
//                                .height(191.dp)
//                                .clickable { navController.navigate(Screen.OpportunitiesAndBenefits.route) },
//                            contentScale = ContentScale.Inside
//                        )
//
//                        Image(
//                            painter = painterResource(id = R.drawable.gifts_22),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .weight(1f)
//                                .height(200.dp)
//                                .clickable {
//                                    navController.navigate(Screen.Gifts.route)
//                                },
//                            contentScale = ContentScale.Inside
//                        )
//                    }
//                }
//
//                item {
//                    Spacer(modifier = Modifier.height(16.dp))
//
//                    // Блок уведомлений
//                    Box(
//                        modifier = Modifier.fillMaxWidth(),
//                        contentAlignment = Alignment.CenterEnd
//                    ) {
//                        Card(
//                            modifier = Modifier
//                                .width(200.dp),
//                            shape = RoundedCornerShape(16.dp),
//                            colors = CardDefaults.cardColors(containerColor = Color.White)
//                        ) {
//                            Column(
//                                modifier = Modifier
//                                    .fillMaxWidth()
//                                    .padding(20.dp)
//                            ) {
//                                Row(
//                                    modifier = Modifier.fillMaxWidth(),
//                                    horizontalArrangement = Arrangement.SpaceBetween,
//                                    verticalAlignment = Alignment.CenterVertically
//                                ) {
//                                    Text(
//                                        text = "Уведомления",
//                                        fontSize = 16.sp,
//                                        fontWeight = FontWeight.Medium
//                                    )
//                                    Image(
//                                        painter = painterResource(id = R.drawable.notification_icon),
//                                        contentDescription = null,
//                                        modifier = Modifier.size(24.dp)
//                                    )
//                                }
//                                Spacer(modifier = Modifier.height(8.dp))
//                                Text(
//                                    text = "У вас 2 новых сообщения",
//                                    fontSize = 14.sp,
//                                    color = Color.Gray
//                                )
//                            }
//                        }
//                    }
//                }
//            }
//        }
//
//        // Нижняя навигация
//        Box(
//            modifier = Modifier
//                .fillMaxWidth()
//                .align(Alignment.BottomCenter)
//                .padding(horizontal = 10.dp, vertical = 8.dp)
//        ) {
//            Card(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(56.dp),
//                shape = RoundedCornerShape(28.dp),
//                colors = CardDefaults.cardColors(containerColor = Color.White)
//            ) {
//                Row(
//                    modifier = Modifier
//                        .fillMaxSize()
//                        .padding(horizontal = 24.dp),
//                    horizontalArrangement = Arrangement.SpaceBetween,
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Image(
//                        painter = painterResource(id = R.drawable.ic_home),
//                        contentDescription = null,
//                        modifier = Modifier.size(24.dp)
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.ic_document),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.Tasks.route)
//                            }
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.ic_gift),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.Gifts.route)
//                            }
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.ic_menu),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.Schedule.route)
//                            }
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.reaccount),
//                        contentDescription = null,
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable {
//                                navController.navigate(Screen.More.route)
//                            }
//                    )
//                }
//            }
//        }
//    }
} 