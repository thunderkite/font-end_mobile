package com.rosstudent.app.models

data class LoginRequestModel(
    val email: String,
    val password: String
)
