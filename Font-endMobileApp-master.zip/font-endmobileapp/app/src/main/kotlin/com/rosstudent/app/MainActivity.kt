package com.rosstudent.app

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.rememberNavController
import com.rosstudent.app.enums.EducationType
import com.rosstudent.app.managers.ContextManager
import com.rosstudent.app.managers.UserManager
import com.rosstudent.app.models.StudentModel
import com.rosstudent.app.navigation.SetupNavGraph
import com.rosstudent.app.theme.AppTheme
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ContextManager.initialize(this)
        UserManager.logout() // уберем для релиза, оставляем для тестов
        setContent {
            AppTheme {
                val navController = rememberNavController()
                SetupNavGraph(navController = navController)
            }
        }
    }
}