package com.rosstudent.app.models

data class LoginResponseModel(
    val userId: String,
    val firstName: String,
    val lastName: String,
    val middleName: String? = null,
    val email: String,
    val college: String? = null,
    val group: String? = null,
    val role: String,
    val message: String
)
