package com.rosstudent.app.enums

import kotlinx.serialization.Serializable

@Serializable
enum class RolesType {
    Student,
    GroupLeader,
    Guest
    // .... остальные по типу деканов специалсотов и тд.
}