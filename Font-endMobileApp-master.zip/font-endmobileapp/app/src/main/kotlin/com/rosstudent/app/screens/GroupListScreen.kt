package com.rosstudent.app.screens

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.data.ApiClient
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import com.rosstudent.app.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupListScreen(
    navController: NavController,
    isHeadman: Boolean = true
) {
//    val context = LocalContext.current
//    val userDataStore = remember { ContextController(context) }
//    val userData = userDataStore.getUserData()
//    val groupName = userData?.group ?: "Не указана" //TODO: поправить
//    val coroutineScope = rememberCoroutineScope()
//
//    // Проверяем актуальную роль пользователя
//    val currentIsHeadman = userDataStore.isHeadman()
//    Log.d("GroupListScreen", "isHeadman parameter: $isHeadman, current value from store: $currentIsHeadman")
//
//    // Если текущий пользователь НЕ староста, перенаправляем обратно
//    LaunchedEffect(currentIsHeadman) {
//        if (!currentIsHeadman) {
//            Log.d("GroupListScreen", "User is not headman, navigating back")
//            navController.popBackStack()
//        }
//    }
//
//    var searchQuery by remember { mutableStateOf("") }
//    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
//    var isLoading by remember { mutableStateOf(true) }
//    var errorMessage by remember { mutableStateOf<String?>(null) }
//
//    // Логируем данные для отладки
//    LaunchedEffect(key1 = true) {
//        Log.d("GroupListScreen", "User data: $userData")
//        Log.d("GroupListScreen", "Group name: $groupName")
//
//        // Пытаемся получить актуальные данные пользователя из API
//        userData?.email?.let { email ->
//            try {
//                val updatedUserData = ApiClient.Companion.getUserByEmail(email)
//                Log.d("GroupListScreen", "Updated user data from API: $updatedUserData")
//
//                if (updatedUserData != null && updatedUserData.group != null && updatedUserData.group != userData.group) {
//                    // Если группа изменилась, обновляем данные
//                    Log.d("GroupListScreen", "Updating user data with new group: ${updatedUserData.group}")
//                    val mergedData = userData.copy(group = updatedUserData.group)
//                    userDataStore.saveUserData(mergedData)
//                    // Перезагружаем список студентов с новой группой
//                    val actualGroup = updatedUserData.group ?: "Не указана" //TODO: поправить
//                    if (actualGroup != "Не указана" && !actualGroup.isBlank()) {
//                        try {
//                            val fetchedStudents = ApiClient.Companion.getStudentsByGroup(actualGroup)
//                            students = fetchedStudents
//                            errorMessage = if (fetchedStudents.isEmpty()) {
//                                "Студенты группы $actualGroup не найдены" //TODO: поправить
//                            } else null
//                        } catch (e: Exception) {
//                            errorMessage = "Ошибка загрузки данных: ${e.message}" //TODO: поправить
//                        } finally {
//                            isLoading = false
//                        }
//                    }
//                }
//            } catch (e: Exception) {
//                Log.e("GroupListScreen", "Error updating user data", e)
//            }
//        }
//    }
//
//    // Загружаем список студентов группы при запуске экрана
//    LaunchedEffect(key1 = groupName) {
//        try {
//            // Проверяем, указана ли группа
//            if (groupName == "Не указана" || groupName.isBlank() || groupName == "Загрузка...") { //TODO: поправить
//                errorMessage = "Группа не указана. Пожалуйста, укажите группу в профиле." //TODO: поправить
//                isLoading = false
//                return@LaunchedEffect
//            }
//
//            // Получаем данные из API
//            Log.d("GroupListScreen", "Fetching students for group: $groupName")
//            val fetchedStudents = ApiClient.Companion.getStudentsByGroup(groupName)
//            Log.d("GroupListScreen", "Fetched ${fetchedStudents.size} students")
//            students = fetchedStudents
//            isLoading = false
//
//            // Проверяем, есть ли студенты
//            if (fetchedStudents.isEmpty()) {
//                errorMessage = "Студенты группы $groupName не найдены" //TODO: поправить
//                Log.d("GroupListScreen", "No students found for group: $groupName")
//            }
//        } catch (e: Exception) {
//            Log.e("GroupListScreen", "Error loading students", e)
//            errorMessage = "Ошибка загрузки данных: ${e.message}" //TODO: поправить
//            isLoading = false
//        }
//    }
//
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color.White)
//    ) {
//        // Верхняя панель
//        TopAppBar(
//            title = {
//                Text(
//                    text = stringResource(R.string.group_list),
//                    fontSize = 20.sp,
//                    fontWeight = FontWeight.Bold
//                )
//            },
//            navigationIcon = {
//                IconButton(onClick = { navController.popBackStack() }) {
//                    Icon(
//                        imageVector = Icons.Default.ArrowBack,
//                        contentDescription = "Back"
//                    )
//                }
//            },
//            colors = TopAppBarDefaults.topAppBarColors(
//                containerColor = Color.White
//            )
//        )
//
//        // Название группы и кнопка выбрать всех
//        Box(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(horizontal = 16.dp, vertical = 8.dp)
//        ) {
//            Text(
//                text = groupName,
//                fontSize = 18.sp,
//                fontWeight = FontWeight.Bold,
//                modifier = Modifier.align(Alignment.CenterStart)
//            )
//
//            TextButton(
//                onClick = {
//                    val allSelected = students.all { it.isSelected }
//                    students = students.map { it.copy(isSelected = !allSelected) }
//                },
//                modifier = Modifier.align(Alignment.CenterEnd)
//            ) {
//                Text(
//                    text = stringResource(R.string.select_all),
//                    color = Color(0xFFE94F09),
//                    fontSize = 14.sp
//                )
//            }
//        }
//
//        // Поле поиска
//        OutlinedTextField(
//            value = searchQuery,
//            onValueChange = { searchQuery = it },
//            placeholder = { Text(stringResource(R.string.search)) },
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(horizontal = 16.dp, vertical = 8.dp),
//            shape = RoundedCornerShape(8.dp),
//            colors = OutlinedTextFieldDefaults.colors(
//                unfocusedBorderColor = Color.LightGray,
//                focusedBorderColor = Color.Gray,
//                unfocusedContainerColor = Color.White,
//                focusedContainerColor = Color.White
//            ),
//            leadingIcon = {
//                Icon(
//                    imageVector = Icons.Default.Search,
//                    contentDescription = "search",
//                    tint = Color.Gray
//                )
//            }
//        )
//
//        // Индикатор загрузки
//        if (isLoading) {
//            Box(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(16.dp),
//                contentAlignment = Alignment.Center
//            ) {
//                CircularProgressIndicator(color = Color(0xFFE94F09))
//            }
//        }
//
//        // Сообщение об ошибке
//        errorMessage?.let { error ->
//            Box(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(16.dp),
//                contentAlignment = Alignment.Center
//            ) {
//                Column(
//                    horizontalAlignment = Alignment.CenterHorizontally,
//                    verticalArrangement = Arrangement.Center
//                ) {
//                    Text(
//                        text = error,
//                        color = Color.Red,
//                        textAlign = TextAlign.Center,
//                        fontSize = 16.sp
//                    )
//
//                    if (error.contains(stringResource(R.string.the_group_is_not_specified))) {
//                        Spacer(modifier = Modifier.height(16.dp))
//                        Button(
//                            onClick = { navController.navigate("edit_profile_screen") },
//                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09))
//                        ) {
//                            Text(stringResource(R.string.specify_the_group))
//                        }
//                    }
//                }
//            }
//        }
//
//        // Список студентов (показываем только если нет ошибок и данные загружены)
//        if (!isLoading && errorMessage == null) {
//            LazyColumn(
//                modifier = Modifier
//                    .fillMaxSize()
//                    .padding(horizontal = 16.dp),
//                verticalArrangement = Arrangement.spacedBy(4.dp)
//            ) {
//                items(students.filter {
//                    searchQuery.isEmpty() ||
//                    "${it.lastName} ${it.firstName} ${it.middleName ?: ""}".contains(searchQuery, ignoreCase = true)
//                }) { student ->
//                    StudentListItem(
//                        student = student,
//                        onSelectionChange = { isSelected ->
//                            students = students.map {
//                                if (it.id == student.id) it.copy(isSelected = isSelected)
//                                else it
//                            }
//                        }
//                    )
//                }
//
//                // Если после фильтрации список пуст, показываем сообщение
//                if (students.isEmpty() || students.none {
//                    searchQuery.isEmpty() ||
//                    "${it.lastName} ${it.firstName} ${it.middleName ?: ""}".contains(searchQuery, ignoreCase = true)
//                }) {
//                    item {
//                        Box(
//                            modifier = Modifier
//                                .fillMaxWidth()
//                                .padding(vertical = 32.dp),
//                            contentAlignment = Alignment.Center
//                        ) {
//                            Text(
//                                text = if (searchQuery.isNotEmpty())
//                                    "По запросу \"$searchQuery\" ничего не найдено" //TODO: поправить
//                                else
//                                    stringResource(R.string.the_list_of_students_is_empty),
//                                color = Color.Gray,
//                                fontSize = 16.sp
//                            )
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
//
//@Composable
//fun StudentListItem(
//    student: Student,
//    onSelectionChange: (Boolean) -> Unit
//) {
//    Row(
//        modifier = Modifier
//            .fillMaxWidth()
//            .padding(vertical = 8.dp),
//        verticalAlignment = Alignment.CenterVertically
//    ) {
//        Text(
//            text = "${student.lastName} ${student.firstName} ${student.middleName ?: ""}".trim(),
//            fontSize = 16.sp,
//            modifier = Modifier.weight(1f)
//        )
//
//        Box(
//            modifier = Modifier
//                .size(24.dp)
//                .background(
//                    color = if (student.isSelected) Color(0xFFE94F09) else Color.White,
//                    shape = CircleShape
//                )
//                .border(
//                    width = 1.dp,
//                    color = if (student.isSelected) Color(0xFFE94F09) else Color.Gray,
//                    shape = CircleShape
//                )
//                .clickable { onSelectionChange(!student.isSelected) },
//            contentAlignment = Alignment.Center
//        ) {
//            if (student.isSelected) {
//                Icon(
//                    imageVector = Icons.Default.Check,
//                    contentDescription = null,
//                    tint = Color.White,
//                    modifier = Modifier.size(16.dp)
//                )
//            }
//        }
//    }
} 