//package com.rosstudent.app.navigation
//
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.LaunchedEffect
//import androidx.compose.runtime.remember
//import androidx.compose.ui.platform.LocalContext
//import androidx.navigation.NavType
//import androidx.navigation.compose.NavHost
//import androidx.navigation.compose.composable
//import androidx.navigation.compose.rememberNavController
//import androidx.navigation.navArgument
//import com.rosstudent.app.data.ContextController
//import com.rosstudent.app.screens.GroupListScreen
//import com.rosstudent.app.screens.ScheduleScreen
//import com.rosstudent.app.screens.StudentDetailsScreen
//import com.rosstudent.app.screens.CreateTaskScreenWithQuestions
//import com.rosstudent.app.screens.TaskAnswersScreen
//import com.rosstudent.app.screens.TaskDetailsScreen
//import com.rosstudent.app.screens.TaskScreen
//
//@Composable
//fun Navigation() {
//    val navController = rememberNavController()
//    val context = LocalContext.current
//    val userDataStore = remember { ContextController(context) }
//    val isLoggedIn = userDataStore.isLoggedIn()
//    val isHeadman = userDataStore.isHeadman()
//    val startDestination = if (isLoggedIn) {
//        Screen.Main.route
//    } else {
//        Screen.Auth.route
//    }
//
//    NavHost(
//        navController = navController,
//        startDestination = startDestination
//    ) {
//        composable("schedule") {
//            ScheduleScreen(navController = navController)
//        }
//
//        composable("group_list/{lessonId}") { backStackEntry ->
//            val lessonId = backStackEntry.arguments?.getString("lessonId") ?: return@composable
//            GroupListScreen(
//                navController = navController
//            )
//        }
//
//        composable("student_details/{studentId}") { backStackEntry ->
//            val studentId = backStackEntry.arguments?.getString("studentId")?.toIntOrNull() ?: return@composable
//            StudentDetailsScreen(
//                studentId = studentId,
//                onBackClick = {
//                    navController.popBackStack()
//                }
//            )
//        }
//
//        // Обновленный маршрут для экрана задач
//        composable(Screen.Tasks.route) {
//            TaskScreen(navController = navController, isHeadman = isHeadman)
//        }
//
//        // Детали задачи по ID
//        composable(
//            "task_details/{taskId}",
//            arguments = listOf(navArgument("taskId") { type = NavType.StringType })
//        ) { backStackEntry ->
//            val taskId = backStackEntry.arguments?.getString("taskId") ?: ""
//            TaskDetailsScreen(taskId = taskId, navController = navController)
//        }
//
//        // Просмотр ответов на задачу
//        composable(
//            "task_answers/{taskId}",
//            arguments = listOf(navArgument("taskId") { type = NavType.StringType })
//        ) { backStackEntry ->
//            val taskId = backStackEntry.arguments?.getString("taskId") ?: ""
//            TaskAnswersScreen(taskId = taskId, navController = navController)
//        }
//
//        // Создание новой задачи (только для старосты)
//        composable("create_task") {
//            if (isHeadman) {
//                CreateTaskScreenWithQuestions(navController = navController)
//            } else {
//                // Если не староста, перенаправляем на главный экран
//                LaunchedEffect(Unit) {
//                    navController.navigate(Screen.Main.route)
//                }
//            }
//        }
//    }
//}