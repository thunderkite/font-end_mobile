package com.rosstudent.app.components

import android.annotation.SuppressLint
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.rosstudent.app.validators.ValidationResult
import com.rosstudent.app.validators.Validator


@Composable
fun <T> TextFieldComponent(
    value: T,
    onValueChange: (String) -> Unit,
    @StringRes placeholderRes: Int,
    validator: Validator<String>? = null,
    showError: Boolean = true,
    @SuppressLint("ModifierParameter") modifier: Modifier = Modifier,
) {
    var hasInteracted by remember { mutableStateOf(false) }

    val stringValue = value.toString()
    val validationResult = validator?.validate(stringValue)
    val isError = validationResult is ValidationResult.Error

    Column {
        TextFieldBase(
            value = stringValue,
            onValueChange = { newValue ->
                hasInteracted = true // Помечаем, что пользователь начал вводить
                onValueChange(newValue)
            },
            placeholderRes = placeholderRes,
            modifier = modifier
        )

        // Показываем ошибку только если пользователь взаимодействовал с полем
        if (showError && isError && hasInteracted) {
            Text(
                text = (validationResult as ValidationResult.Error).message,
                color = Color.Red,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}
