package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import com.rosstudent.app.R
import androidx.compose.foundation.BorderStroke
import androidx.navigation.NavController
import com.rosstudent.app.navigation.Screen
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import android.util.Log
import com.rosstudent.app.components.CustomDropdownField
import com.rosstudent.app.components.CustomSwitch
import com.rosstudent.app.components.CustomTextField
import com.rosstudent.app.data.Answer
import com.rosstudent.app.data.Question
import com.rosstudent.app.data.QuestionOption
import com.rosstudent.app.data.Task
import com.rosstudent.app.data.TaskPriority
import com.rosstudent.app.data.TaskStore
import com.rosstudent.app.data.TaskType

@Composable
fun TaskScreen(
    navController: NavController,
    isHeadman: Boolean = false
) {
    Text("Надо отрефакторить с использованием UserManager и новых моделек данных")
    // TODO: глянь код контекста
    // твой код: расскоментить можно быстро через ctrl + /
//    val context = LocalContext.current
//    val userDataStore = remember { UserDataStore(context) }
//    val currentIsHeadman = userDataStore.isHeadman()

//    // Логируем для отладки // tetstststtsts
//    LaunchedEffect(key1 = true) {
//        Log.d("TaskScreen", "Parameter isHeadman: $isHeadman, Current from store: $currentIsHeadman")
//    }
//
//    // Всегда используем значение из хранилища
//    val effectiveIsHeadman = currentIsHeadman
//
//    Scaffold(
//        bottomBar = {
//            Box(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(horizontal = 10.dp, vertical = 8.dp)
//            ) {
//                Card(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .height(56.dp),
//                    shape = RoundedCornerShape(28.dp),
//                    colors = CardDefaults.cardColors(containerColor = Color.White)
//                ) {
//                    Row(
//                        modifier = Modifier
//                            .fillMaxSize()
//                            .padding(horizontal = 24.dp),
//                        horizontalArrangement = Arrangement.SpaceBetween,
//                        verticalAlignment = Alignment.CenterVertically
//                    ) {
//                        Image(
//                            painter = painterResource(id = R.drawable.home_high),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .size(24.dp)
//                                .clickable {
//                                    navController.navigate(Screen.Main.route)
//                                }
//                        )
//                        Image(
//                            painter = painterResource(id = R.drawable.files_orange_high),
//                            contentDescription = null,
//                            modifier = Modifier.size(24.dp)
//                        )
//                        Image(
//                            painter = painterResource(id = R.drawable.ic_gift),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .size(24.dp)
//                                .clickable {
//                                    navController.navigate(Screen.Gifts.route)
//                                }
//                        )
//                        Image(
//                            painter = painterResource(id = R.drawable.ic_menu),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .size(24.dp)
//                                .clickable {
//                                    navController.navigate(Screen.Schedule.route)
//                                }
//                        )
//                        Image(
//                            painter = painterResource(id = R.drawable.reaccount),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .size(24.dp)
//                                .clickable {
//                                    navController.navigate(Screen.More.route) {
//                                        popUpTo(navController.graph.startDestinationId)
//                                    }
//                                }
//                        )
//                    }
//                }
//            }
//        }
//    ) { paddingValues ->
//        Box(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(paddingValues)
//                .background(Color.White)
//        ) {
//            if (effectiveIsHeadman) {
//                HeadmanTaskScreen(navController)
//            } else {
//                StudentTaskScreen(navController)
//            }
//
//            // Кнопка добавления новой задачи (FAB) - только для старосты
//            if (effectiveIsHeadman) {
//                FloatingActionButton(
//                    onClick = {
//                        navController.navigate("create_task")
//                    },
//                    modifier = Modifier
//                        .align(Alignment.BottomEnd)
//                        .padding(bottom = 16.dp, end = 16.dp),
//                    containerColor = Color(0xFFE94F09),
//                    contentColor = Color.White
//                ) {
//                    Icon(Icons.Default.Add, contentDescription = "add task")
//                }
//            }
//        }
//    }
//}
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//private fun HeadmanTaskScreen(navController: NavController) {
//    val context = LocalContext.current
//    val taskStore = remember { TaskStore(context) }
//    var selectedTab by remember { mutableStateOf(TaskPriority.NORMAL) }
//    var tasks by remember { mutableStateOf(emptyList<Task>()) }
//
//    // Загружаем задачи при изменении выбранной вкладки
//    LaunchedEffect(selectedTab) {
//        tasks = taskStore.getTasksByTypeAndPriority(priority = selectedTab)
//    }
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color.White)
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(top = 24.dp)
//                .verticalScroll(rememberScrollState()),
//            horizontalAlignment = Alignment.CenterHorizontally
//        ) {
//            Text(
//                text = stringResource(R.string.tasks),
//                fontSize = 24.sp,
//                fontWeight = FontWeight.Bold,
//                modifier = Modifier.padding(bottom = 16.dp)
//            )
//            // Переключатели
//            Row(
//                modifier = Modifier.padding(bottom = 16.dp),
//                horizontalArrangement = Arrangement.spacedBy(12.dp)
//            ) {
//                val tabTitles = listOf(
//                    TaskPriority.NORMAL to "Актуальное",
//                    TaskPriority.URGENT to "Срочные",
//                    TaskPriority.ARCHIVED to "Архив"
//                )
//                tabTitles.forEach { (priority, title) ->
//                    val isSelected = selectedTab == priority
//                    Button(
//                        onClick = { selectedTab = priority },
//                        colors = if (isSelected)
//                            ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09))
//                        else
//                            ButtonDefaults.outlinedButtonColors(containerColor = Color.White),
//                        border = if (!isSelected) BorderStroke(1.dp, Color(0xFFE94F09)) else null,
//                        shape = RoundedCornerShape(50),
//                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
//                        elevation = null,
//                        modifier = Modifier.height(36.dp)
//                    ) {
//                        Text(
//                            text = title,
//                            color = if (isSelected) Color.White else Color(0xFFE94F09),
//                            fontSize = 15.sp,
//                            fontWeight = FontWeight.Medium
//                        )
//                    }
//                }
//            }
//
//            // Карточки ex_4 и ex_5 для задач старосты
//            val localNavController = navController
//            Image(
//                painter = painterResource(id = R.drawable.ex_4),
//                contentDescription = "ex_4",
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(320.dp)
//                    .padding(vertical = 8.dp)
//                    .clickable {
//                        localNavController.navigate("headman_exhibition_ex4")
//                    }
//            )
//            Image(
//                painter = painterResource(id = R.drawable.ex_5),
//                contentDescription = "ex_5",
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(320.dp)
//                    .padding(vertical = 8.dp)
//                    .clickable {
//                        // Пока просто делаем кликабельной, без навигации
//                        // TODO: Определить действие при клике на ex_5
//                    }
//            )
//
//            // Список задач
//            if (tasks.isEmpty()) {
//                // Если задач нет, показываем заглушку
//                Text(
//                    text = stringResource(R.string.you_dont_have_any_tasks_yet),
//                    color = Color.Gray,
//                    fontSize = 16.sp,
//                    modifier = Modifier.padding(top = 32.dp)
//                )
//            } else {
//                // Отображаем задачи
//                Column(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(horizontal = 16.dp),
//                    verticalArrangement = Arrangement.spacedBy(16.dp)
//                ) {
//                    tasks.forEach { task ->
//                        TaskCard(
//                            task = task,
//                            navController = navController
//                        )
//                    }
//                }
//            }
//        }
//    }
//}
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//private fun QuestionCard(
//    question: QuestionItem,
//    onDelete: () -> Unit,
//    onQuestionUpdate: (QuestionItem) -> Unit
//) {
//    var expanded by remember { mutableStateOf(false) }
//
//    Card(
//        modifier = Modifier
//            .fillMaxWidth(),
//        shape = RoundedCornerShape(8.dp),
//        border = BorderStroke(1.dp, Color(0xFFE0E0E0))
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(16.dp)
//        ) {
//            // Поле вопроса
//            CustomTextField(
//                value = question.question,
//                onValueChange = { onQuestionUpdate(question.copy(question = it)) },
//                placeholderText = stringResource(R.string.question),
//                transparentBackground = true
//            )
//
//            // Выпадающий список типа
//            CustomDropdownField(
//                value = question.type.toDisplayString(),
//                expanded = expanded,
//                onExpandedChange = { expanded = it }
//            ) {
//                QuestionType.values().forEach { type ->
//                    DropdownMenuItem(
//                        text = { Text(type.toDisplayString()) },
//                        onClick = {
//                            onQuestionUpdate(question.copy(type = type))
//                            expanded = false
//                        }
//                    )
//                }
//            }
//
//            // Описание (для всех типов)
//            CustomTextField(
//                value = question.description,
//                onValueChange = { onQuestionUpdate(question.copy(description = it)) },
//                placeholderText = stringResource(R.string.description),
//                transparentBackground = true
//            )
//
//            // Специфичные поля в зависимости от типа
//            when (question.type) {
//                QuestionType.TEXT -> {
//                    // Для текстового вопроса дополнительные поля не нужны
//                }
//                QuestionType.FILE_LINK -> {
//                    Text(
//                        text = stringResource(R.string.upload_the_file_to_your_cloud),
//                        color = Color(0xFF757575),
//                        fontSize = 12.sp,
//                        modifier = Modifier.padding(vertical = 8.dp)
//                    )
//                    CustomTextField(
//                        value = question.link,
//                        onValueChange = { onQuestionUpdate(question.copy(link = it)) },
//                        placeholderText = stringResource(R.string.link),
//                        transparentBackground = true
//                    )
//                }
//                QuestionType.EXTERNAL_LINK -> {
//                    CustomTextField(
//                        value = question.link,
//                        onValueChange = { onQuestionUpdate(question.copy(link = it)) },
//                        placeholderText = stringResource(R.string.link),
//                        transparentBackground = true
//                    )
//                }
//                QuestionType.MULTIPLE_CHOICE -> {
//                    Column(
//                        modifier = Modifier.fillMaxWidth(),
//                        verticalArrangement = Arrangement.spacedBy(8.dp)
//                    ) {
//                        question.options.forEachIndexed { index, option ->
//                            Row(
//                                verticalAlignment = Alignment.CenterVertically,
//                                modifier = Modifier.fillMaxWidth()
//                            ) {
//                                Checkbox(
//                                    checked = false,
//                                    onCheckedChange = null,
//                                    enabled = false
//                                )
//                                CustomTextField(
//                                    value = option,
//                                    onValueChange = { newValue ->
//                                        val newOptions = question.options.toMutableList()
//                                        newOptions[index] = newValue
//                                        onQuestionUpdate(question.copy(options = newOptions))
//                                    },
//                                    placeholderText = stringResource(R.string.option_placeholder, index + 1),
//                                    modifier = Modifier
//                                        .weight(1f)
//                                        .padding(start = 8.dp),
//                                    transparentBackground = true
//                                )
//                            }
//                        }
//                        TextButton(
//                            onClick = {
//                                onQuestionUpdate(question.copy(options = question.options + ""))
//                            },
//                            modifier = Modifier.fillMaxWidth()
//                        ) {
//                            Text(stringResource(R.string.add_an_option))
//                        }
//                    }
//                }
//                QuestionType.DROPDOWN -> {
//                    Column(
//                        modifier = Modifier.fillMaxWidth(),
//                        verticalArrangement = Arrangement.spacedBy(8.dp)
//                    ) {
//                        question.options.forEachIndexed { index, option ->
//                            Row(
//                                verticalAlignment = Alignment.CenterVertically,
//                                modifier = Modifier.fillMaxWidth()
//                            ) {
//                                Text("${index + 1}.", modifier = Modifier.padding(end = 8.dp))
//                                CustomTextField(
//                                    value = option,
//                                    onValueChange = { updatedOption ->
//                                        val newOptions = question.options.toMutableList()
//                                        newOptions[index] = updatedOption
//                                        onQuestionUpdate(question.copy(options = newOptions))
//                                    },
//                                    placeholderText = stringResource(R.string.option_placeholder, index + 1),
//                                    modifier = Modifier
//                                        .weight(1f)
//                                        .padding(start = 8.dp),
//                                    transparentBackground = true
//                                )
//                            }
//                        }
//                        TextButton(
//                            onClick = {
//                                onQuestionUpdate(question.copy(options = question.options + ""))
//                            },
//                            modifier = Modifier.fillMaxWidth()
//                        ) {
//                            Text(stringResource(R.string.add_an_option))
//                        }
//                    }
//                }
//            }
//
//            // Нижняя строка с иконками и переключателем
//            Row(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(top = 8.dp),
//                horizontalArrangement = Arrangement.SpaceBetween,
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                Row(
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Icon(
//                        imageVector = Icons.Default.Share,
//                        contentDescription = "Copy",
//                        modifier = Modifier.size(24.dp),
//                        tint = Color.Gray
//                    )
//                    Spacer(modifier = Modifier.width(16.dp))
//                    Icon(
//                        imageVector = Icons.Default.Delete,
//                        contentDescription = "Delete",
//                        modifier = Modifier
//                            .size(24.dp)
//                            .clickable { onDelete() },
//                        tint = Color.Gray
//                    )
//                }
//                Row(
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Text(
//                        stringResource(R.string.mandatory_question),
//                        fontSize = 14.sp,
//                        color = Color.Gray
//                    )
//                    Spacer(modifier = Modifier.width(8.dp))
//                    CustomSwitch(
//                        checked = question.isRequired,
//                        onCheckedChange = {
//                            onQuestionUpdate(question.copy(isRequired = it))
//                        }
//                    )
//                }
//            }
//        }
//    }
//}
//
//@Composable
//private fun SwitchRow(text: String, initialChecked: Boolean = false, onCheckedChange: ((Boolean) -> Unit)? = null) {
//    var checked by remember { mutableStateOf(initialChecked) }
//
//    Row(
//        modifier = Modifier
//            .fillMaxWidth()
//            .padding(vertical = 8.dp),
//        horizontalArrangement = Arrangement.SpaceBetween,
//        verticalAlignment = Alignment.CenterVertically
//    ) {
//        Text(
//            text = text,
//            fontSize = 14.sp,
//            modifier = Modifier.weight(1f)
//        )
//        CustomSwitch(
//            checked = checked,
//            onCheckedChange = {
//                checked = it
//                onCheckedChange?.invoke(it)
//            }
//        )
//    }
//}
//
//@Composable
//private fun StudentTaskCard(
//    iconRes: Int,
//    bgColor: Color,
//    label: String,
//    labelColor: Color,
//    title: String,
//    date: String,
//    description: String,
//    buttonColor: Color,
//    buttonText: String = stringResource(R.string.perform),
//    onButtonClick: () -> Unit = {}
//) {
//    Box(
//        modifier = Modifier
//            .fillMaxWidth()
//            .padding(vertical = 6.dp)
//    ) {
//        Row(
//            modifier = Modifier
//                .background(bgColor, shape = RoundedCornerShape(20.dp))
//                .fillMaxWidth()
//                .padding(12.dp),
//            verticalAlignment = Alignment.Top
//        ) {
//            Image(
//                painter = painterResource(id = iconRes),
//                contentDescription = null,
//                modifier = Modifier
//                    .size(36.dp)
//                    .padding(top = 2.dp)
//            )
//            Spacer(modifier = Modifier.width(8.dp))
//            Column(modifier = Modifier.weight(1f)) {
//                Row(verticalAlignment = Alignment.CenterVertically) {
//                    Text(
//                        text = label,
//                        color = labelColor,
//                        fontSize = 13.sp,
//                        fontWeight = FontWeight.Bold
//                    )
//                    Spacer(modifier = Modifier.width(8.dp))
//                    Text(
//                        text = date,
//                        color = Color.Gray,
//                        fontSize = 12.sp,
//                        modifier = Modifier.weight(1f),
//                        textAlign = TextAlign.End
//                    )
//                }
//                Text(
//                    text = title,
//                    fontWeight = FontWeight.Bold,
//                    fontSize = 15.sp,
//                    color = Color.Black,
//                    modifier = Modifier.padding(top = 2.dp, bottom = 2.dp)
//                )
//                Text(
//                    text = description,
//                    fontSize = 13.sp,
//                    color = Color.DarkGray,
//                    maxLines = 2
//                )
//            }
//            Spacer(modifier = Modifier.width(8.dp))
//            Button(
//                onClick = onButtonClick,
//                colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
//                shape = RoundedCornerShape(16.dp),
//                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
//                modifier = Modifier.align(Alignment.Top)
//            ) {
//                Text(
//                    text = buttonText,
//                    color = Color.White,
//                    fontSize = 13.sp
//                )
//                Icon(
//                    painter = painterResource(id = R.drawable.vk),
//                    contentDescription = null,
//                    tint = Color.White,
//                    modifier = Modifier.size(16.dp).padding(start = 2.dp)
//                )
//            }
//        }
//    }
//}
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//private fun StudentTaskScreen(navController: NavController) {
//    val context = LocalContext.current
//    val taskStore = remember { TaskStore(context) }
//    val userDataStore = remember { UserDataStore(context) }
//    var selectedTab by remember { mutableStateOf(TaskPriority.NORMAL) }
//    var tasks by remember { mutableStateOf(emptyList<Task>()) }
//    val userData = userDataStore.getUserData()
//
//    // Загружаем задачи при изменении выбранной вкладки
//    LaunchedEffect(selectedTab) {
//        // Получаем ID группы пользователя
//        val userGroup = userData?.group
//
//        // Получаем задачи для группы пользователя с соответствующим приоритетом
//        tasks = if (userGroup != null) {
//            val groupTasks = taskStore.getTasksByGroup(userGroup)
//            groupTasks.filter { it.priority == selectedTab }
//        } else {
//            taskStore.getTasksByTypeAndPriority(priority = selectedTab)
//        }
//    }
//
//    Box(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color.White)
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxSize()
//                .padding(bottom = 80.dp)
//                .padding(top = 24.dp)
//                .verticalScroll(rememberScrollState()),
//            horizontalAlignment = Alignment.CenterHorizontally
//        ) {
//            Text(
//                text = "Задачи",
//                fontSize = 24.sp,
//                fontWeight = FontWeight.Bold,
//                modifier = Modifier.padding(bottom = 16.dp)
//            )
//            // Переключатели
//            Row(
//                modifier = Modifier.padding(bottom = 16.dp),
//                horizontalArrangement = Arrangement.spacedBy(12.dp)
//            ) {
//                val tabTitles = listOf(
//                    TaskPriority.NORMAL to "Актуальное",
//                    TaskPriority.URGENT to "Срочные",
//                    TaskPriority.ARCHIVED to "Архив"
//                )
//                tabTitles.forEach { (priority, title) ->
//                    val isSelected = selectedTab == priority
//                    Button(
//                        onClick = { selectedTab = priority },
//                        colors = if (isSelected)
//                            ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09))
//                        else
//                            ButtonDefaults.outlinedButtonColors(containerColor = Color.White),
//                        border = if (!isSelected) BorderStroke(1.dp, Color(0xFFE94F09)) else null,
//                        shape = RoundedCornerShape(50),
//                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
//                        elevation = null,
//                        modifier = Modifier.height(36.dp)
//                    ) {
//                        Text(
//                            text = title,
//                            color = if (isSelected) Color.White else Color(0xFFE94F09),
//                            fontSize = 15.sp,
//                            fontWeight = FontWeight.Medium
//                        )
//                    }
//                }
//            }
//
//            // Демонстрационные карточки ex_1, ex_2, ex_3
//            val localNavController = navController
//            Image(
//                painter = painterResource(id = R.drawable.ex_1),
//                contentDescription = "ex_1",
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(160.dp)
//                    .padding(vertical = 8.dp)
//                    .clickable {
//                        localNavController.navigate("task_details/ex_1")
//                    }
//            )
//            Image(
//                painter = painterResource(id = R.drawable.ex_2),
//                contentDescription = "ex_2",
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(160.dp)
//                    .padding(vertical = 8.dp)
//                    .clickable {
//                        localNavController.navigate("task_details/ex_2")
//                    }
//            )
//            Image(
//                painter = painterResource(id = R.drawable.ex_3),
//                contentDescription = "ex_3",
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(160.dp)
//                    .padding(vertical = 8.dp)
//                    .clickable {
//                        localNavController.navigate("task_details/ex_3")
//                    }
//            )
//
//            // Список задач
//            if (tasks.isEmpty()) {
//                // Если задач нет, показываем заглушку
//                Text(
//                    text = stringResource(R.string.you_dont_have_any_tasks_yet),
//                    color = Color.Gray,
//                    fontSize = 16.sp,
//                    modifier = Modifier.padding(top = 32.dp)
//                )
//            } else {
//                // Отображаем задачи
//                Column(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(horizontal = 16.dp),
//                    verticalArrangement = Arrangement.spacedBy(16.dp)
//                ) {
//                    tasks.forEach { task ->
//                        TaskCard(
//                            task = task,
//                            navController = navController
//                        )
//                    }
//                }
//            }
//        }
//    }
//}
//
//@Composable
//fun TaskCard(
//    task: Task,
//    navController: NavController
//) {
//    val taskTypeColor = when (task.type) {
//        TaskType.FEDERAL -> Color(0xFFE3F2FD) // Голубой фон для федеральных задач
//        TaskType.EDUCATIONAL -> Color(0xFFE8F5E9) // Зеленый фон для учебных задач
//        TaskType.HEADMAN -> Color(0xFFFFF3E0) // Персиковый фон для задач от старосты
//        else -> Color(0xFFEEEEEE) // Серый фон для неизвестных типов
//    }
//
//    val iconRes = when (task.type) {
//        TaskType.FEDERAL -> R.drawable.ic_document
//        TaskType.EDUCATIONAL -> R.drawable.ic_document
//        TaskType.HEADMAN -> R.drawable.ic_document
//        else -> R.drawable.ic_document
//    }
//
//    val typeText = when (task.type) {
//        TaskType.FEDERAL -> "Федеральная задача"
//        TaskType.EDUCATIONAL -> "Учебная задача"
//        TaskType.HEADMAN -> "Задача от старосты"
//        else -> "Задача"
//    }
//
//    val context = LocalContext.current
//    val userDataStore = remember { UserDataStore(context) }
//    val taskStore = remember { TaskStore(context) }
//    val userData = userDataStore.getUserData()
//    var isCompleted by remember { mutableStateOf(false) }
//
//    // Проверяем, выполнена ли задача текущим пользователем
//    LaunchedEffect(key1 = task.id) {
//        userData?.let { user ->
//            isCompleted = taskStore.isTaskCompletedByUser(task.id, user.userId)
//        }
//    }
//
//    Card(
//        modifier = Modifier
//            .fillMaxWidth()
//            .padding(vertical = 8.dp),
//        shape = RoundedCornerShape(16.dp),
//        colors = CardDefaults.cardColors(containerColor = taskTypeColor)
//    ) {
//        Column(
//            modifier = Modifier
//                .fillMaxWidth()
//                .padding(16.dp)
//        ) {
//            // Заголовок с иконкой и типом задачи
//            Row(
//                verticalAlignment = Alignment.CenterVertically,
//                modifier = Modifier.padding(bottom = 12.dp)
//            ) {
//                Image(
//                    painter = painterResource(id = iconRes),
//                    contentDescription = null,
//                    modifier = Modifier.size(24.dp)
//                )
//                Spacer(modifier = Modifier.width(8.dp))
//                Text(
//                    text = typeText,
//                    color = Color.DarkGray,
//                    fontSize = 14.sp
//                )
//
//                if (isCompleted) {
//                    Spacer(modifier = Modifier.weight(1f))
//                    Card(
//                        shape = RoundedCornerShape(12.dp),
//                        colors = CardDefaults.cardColors(containerColor = Color(0xFF4CAF50))
//                    ) {
//                        Text(
//                            text = stringResource(R.string.done),
//                            color = Color.White,
//                            fontSize = 12.sp,
//                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
//                        )
//                    }
//                }
//            }
//
//            // Название задачи
//            Text(
//                text = task.title,
//                fontWeight = FontWeight.Bold,
//                fontSize = 18.sp,
//                modifier = Modifier.padding(bottom = 8.dp)
//            )
//
//            // Дедлайн
//            Text(
//                text = task.deadline,
//                color = Color.Gray,
//                fontSize = 14.sp,
//                modifier = Modifier.padding(bottom = 8.dp)
//            )
//
//            // Описание задачи
//            Text(
//                text = task.description,
//                fontSize = 14.sp,
//                modifier = Modifier.padding(bottom = 16.dp)
//            )
//
//            // Кнопка "Выполнить"
//            if (!isCompleted) {
//                Button(
//                    onClick = {
//                        navController.navigate("task_details/${task.id}")
//                    },
//                    modifier = Modifier.align(Alignment.End),
//                    colors = ButtonDefaults.buttonColors(
//                        containerColor = when (task.type) {
//                            TaskType.FEDERAL -> Color(0xFF2196F3) // Синий для федеральных
//                            TaskType.EDUCATIONAL -> Color(0xFF4CAF50) // Зеленый для учебных
//                            TaskType.HEADMAN -> Color(0xFFE94F09) // Оранжевый для задач от старосты
//                            else -> Color(0xFF9E9E9E) // Серый для неизвестных типов
//                        }
//                    ),
//                    shape = RoundedCornerShape(50)
//                ) {
//                    Text(
//                        text = stringResource(R.string.perform),
//                        color = Color.White,
//                        fontSize = 14.sp
//                    )
//                }
//            } else {
//                // Кнопка "Просмотреть ответы" для выполненных задач
//                OutlinedButton(
//                    onClick = {
//                        navController.navigate("task_answers/${task.id}")
//                    },
//                    modifier = Modifier.align(Alignment.End),
//                    border = BorderStroke(1.dp, Color(0xFF4CAF50)),
//                    shape = RoundedCornerShape(50)
//                ) {
//                    Text(
//                        text = stringResource(R.string.view_responses),
//                        color = Color(0xFF4CAF50),
//                        fontSize = 14.sp
//                    )
//                }
//            }
//        }
//    }
//}
//
//data class TaskItem(
//    val title: String,
//    val description: String
//)
//
//data class QuestionItem(
//    val question: String = "",
//    val type: QuestionType = QuestionType.TEXT,
//    val description: String = "",
//    val link: String = "",
//    val options: List<String> = listOf(""),
//    val isRequired: Boolean = false
//)
//
//enum class QuestionType {
//    TEXT,
//    FILE_LINK,
//    EXTERNAL_LINK,
//    MULTIPLE_CHOICE,
//    DROPDOWN;
//
//    fun toDisplayString(): String = when (this) {
//        TEXT -> "Текст"
//        FILE_LINK -> "Ссылка на файл"
//        EXTERNAL_LINK -> "Внешняя ссылка"
//        MULTIPLE_CHOICE -> "Несколько из списка"
//        DROPDOWN -> "Раскрывающийся список"
//    }
//}
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun TaskDetailsScreen(
//    taskId: String,
//    navController: NavController? = null
//) {
//    val context = LocalContext.current
//    val taskStore = remember { TaskStore(context) }
//    val userDataStore = remember { UserDataStore(context) }
//    val userData = userDataStore.getUserData()
//
//    var task by remember { mutableStateOf<Task?>(null) }
//    var questions by remember { mutableStateOf<List<Question>>(emptyList()) }
//    var questionOptions by remember { mutableStateOf<Map<String, List<QuestionOption>>>(emptyMap()) }
//
//    // Состояние для ответов пользователя
//    var textAnswers by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
//    var fileAnswers by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
//    var selectedOptions by remember { mutableStateOf<Map<String, List<String>>>(emptyMap()) }
//
//    // Загружаем данные задачи и вопросы
//    LaunchedEffect(taskId) {
//        // Находим задачу по ID
//        task = taskStore.getAllTasks().find { it.id == taskId }
//
//        // Загружаем вопросы для задачи
//        questions = taskStore.getQuestionsForTask(taskId)
//
//        // Загружаем варианты ответов для каждого вопроса
//        val options = mutableMapOf<String, List<QuestionOption>>()
//        for (question in questions) {
//            options[question.questionId] = taskStore.getOptionsForQuestion(question.questionId)
//        }
//        questionOptions = options
//    }
//
//    val requiredColor = Color(0xFFE94F09)
//    val scrollState = rememberScrollState()
//
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .background(Color.White)
//            .verticalScroll(scrollState)
//            .padding(horizontal = 16.dp, vertical = 24.dp),
//        horizontalAlignment = Alignment.CenterHorizontally
//    ) {
//        if (task != null) {
//            Text(
//                text = task!!.title,
//                fontSize = 22.sp,
//                fontWeight = FontWeight.Bold,
//                modifier = Modifier.padding(bottom = 8.dp)
//            )
//            Divider(color = Color(0xFFE0E0E0), thickness = 2.dp, modifier = Modifier.padding(bottom = 8.dp))
//            Text(
//                text = task!!.description,
//                fontSize = 15.sp,
//                color = Color.DarkGray,
//                textAlign = TextAlign.Center,
//                modifier = Modifier.padding(bottom = 8.dp)
//            )
//            Divider(color = Color(0xFFE0E0E0), thickness = 2.dp, modifier = Modifier.padding(bottom = 8.dp))
//            Text(
//                text = stringResource(R.string.mandatory_questions_are_marked),
//                color = requiredColor,
//                fontSize = 13.sp,
//                modifier = Modifier.padding(bottom = 8.dp)
//            )
//
//            // Отображаем вопросы
//            for (question in questions) {
//                Card(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(vertical = 3.dp),
//                    shape = RoundedCornerShape(10.dp),
//                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F8F8)),
//                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
//                ) {
//                    Column(modifier = Modifier.padding(10.dp)) {
//                        Row(verticalAlignment = Alignment.CenterVertically) {
//                            Text(
//                                text = question.questionText,
//                                fontWeight = FontWeight.Bold,
//                                fontSize = 16.sp,
//                                color = Color.Black
//                            )
//                            if (question.required) {
//                                Text(
//                                    text = " *",
//                                    fontWeight = FontWeight.Bold,
//                                    fontSize = 16.sp,
//                                    color = requiredColor
//                                )
//                            }
//                        }
//
//                        // Отображаем поле для ответа в зависимости от типа вопроса
//                        when (question.questionType) {
//                            "TEXT" -> {
//                                CustomTextField(
//                                    value = textAnswers[question.questionId] ?: "",
//                                    onValueChange = {
//                                        textAnswers = textAnswers.toMutableMap().apply {
//                                            put(question.questionId, it)
//                                        }
//                                    },
//                                    placeholderText = stringResource(R.string.enter_your_answer),
//                                    transparentBackground = true
//                                )
//                            }
//                            "FILE" -> {
//                                CustomTextField(
//                                    value = fileAnswers[question.questionId] ?: "",
//                                    onValueChange = {
//                                        fileAnswers = fileAnswers.toMutableMap().apply {
//                                            put(question.questionId, it)
//                                        }
//                                    },
//                                    placeholderText = stringResource(R.string.the_link_to_your_file),
//                                    transparentBackground = true
//                                )
//                                Text(
//                                    text = stringResource(R.string.upload_the_file_to_your_cloud_and_insert_the_link),
//                                    fontSize = 12.sp,
//                                    color = Color.Gray,
//                                    modifier = Modifier.padding(top = 4.dp)
//                                )
//                            }
//                            "MULTIPLE_CHOICE" -> {
//                                val options = questionOptions[question.questionId] ?: emptyList()
//                                val currentSelected = selectedOptions[question.questionId] ?: emptyList()
//
//                                Column(
//                                    modifier = Modifier
//                                        .fillMaxWidth()
//                                        .padding(top = 8.dp)
//                                ) {
//                                    for (option in options) {
//                                        Row(
//                                            verticalAlignment = Alignment.CenterVertically,
//                                            modifier = Modifier.padding(vertical = 4.dp)
//                                        ) {
//                                            Checkbox(
//                                                checked = currentSelected.contains(option.optionId),
//                                                onCheckedChange = { checked ->
//                                                    val newSelected = if (checked) {
//                                                        currentSelected + option.optionId
//                                                    } else {
//                                                        currentSelected - option.optionId
//                                                    }
//                                                    selectedOptions = selectedOptions.toMutableMap().apply {
//                                                        put(question.questionId, newSelected)
//                                                    }
//                                                },
//                                                modifier = Modifier.size(20.dp)
//                                            )
//                                            Spacer(modifier = Modifier.width(8.dp))
//                                            Text(
//                                                text = option.optionText,
//                                                fontSize = 16.sp
//                                            )
//                                        }
//                                    }
//                                }
//                            }
//                            "DROPDOWN" -> {
//                                val options = questionOptions[question.questionId] ?: emptyList()
//                                var expanded by remember { mutableStateOf(false) }
//                                val currentSelected = selectedOptions[question.questionId]?.firstOrNull() ?: ""
//                                val selectedText = options.find { it.optionId == currentSelected }?.optionText ?: stringResource(R.string.select_from_the_list)
//
//                                ExposedDropdownMenuBox(
//                                    expanded = expanded,
//                                    onExpandedChange = { expanded = it }
//                                ) {
//                                    OutlinedTextField(
//                                        value = selectedText,
//                                        onValueChange = {},
//                                        readOnly = true,
//                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
//                                        modifier = Modifier
//                                            .menuAnchor()
//                                            .fillMaxWidth()
//                                            .padding(top = 8.dp),
//                                        shape = RoundedCornerShape(8.dp),
//                                        singleLine = true
//                                    )
//                                    ExposedDropdownMenu(
//                                        expanded = expanded,
//                                        onDismissRequest = { expanded = false }
//                                    ) {
//                                        for (option in options) {
//                                            DropdownMenuItem(
//                                                text = { Text(option.optionText) },
//                                                onClick = {
//                                                    selectedOptions = selectedOptions.toMutableMap().apply {
//                                                        put(question.questionId, listOf(option.optionId))
//                                                    }
//                                                    expanded = false
//                                                }
//                                            )
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//
//            Spacer(modifier = Modifier.height(24.dp))
//            Button(
//                onClick = {
//                    // Проверяем, заполнены ли все обязательные поля
//                    val requiredQuestions = questions.filter { it.required }
//                    val allRequiredAnswered = requiredQuestions.all { question ->
//                        when (question.questionType) {
//                            "TEXT" -> textAnswers[question.questionId]?.isNotBlank() == true
//                            "FILE" -> fileAnswers[question.questionId]?.isNotBlank() == true
//                            "MULTIPLE_CHOICE", "DROPDOWN" -> selectedOptions[question.questionId]?.isNotEmpty() == true
//                            else -> false
//                        }
//                    }
//
//                    if (allRequiredAnswered) {
//                        // Сохраняем ответы
//                        userData?.let { user ->
//                            for (question in questions) {
//                                val answerId = "${user.userId}_${question.questionId}_${System.currentTimeMillis()}"
//
//                                when (question.questionType) {
//                                    "TEXT" -> {
//                                        val textAnswer = textAnswers[question.questionId]
//                                        if (!textAnswer.isNullOrBlank()) {
//                                            taskStore.saveAnswer(
//                                                Answer(
//                                                    answerId = answerId,
//                                                    userId = user.userId,
//                                                    questionId = question.questionId,
//                                                    textAnswer = textAnswer
//                                                )
//                                            )
//                                        }
//                                    }
//                                    "FILE" -> {
//                                        val fileUrl = fileAnswers[question.questionId]
//                                        if (!fileUrl.isNullOrBlank()) {
//                                            taskStore.saveAnswer(
//                                                Answer(
//                                                    answerId = answerId,
//                                                    userId = user.userId,
//                                                    questionId = question.questionId,
//                                                    textAnswer = fileUrl // Используем textAnswer для хранения URL файла
//                                                )
//                                            )
//                                        }
//                                    }
//                                    "MULTIPLE_CHOICE", "DROPDOWN" -> {
//                                        val selected = selectedOptions[question.questionId]
//                                        if (!selected.isNullOrEmpty()) {
//                                            taskStore.saveAnswer(
//                                                Answer(
//                                                    answerId = answerId,
//                                                    userId = user.userId,
//                                                    questionId = question.questionId
//                                                )
//                                            )
//                                            taskStore.saveSelectedOptions(answerId, selected)
//                                        }
//                                    }
//                                }
//                            }
//
//                            // Отмечаем задачу как выполненную
//                            taskStore.markTaskCompleted(taskId, user.userId)
//
//                            // Возвращаемся к списку задач
//                            navController?.navigate(Screen.Tasks.route)
//                        }
//                    } else {
//                        // Показываем сообщение о необходимости заполнить все обязательные поля
//                        Toast.makeText(
//                            context,
//                            "Пожалуйста, заполните все обязательные поля", //TODO: поправить
//                            Toast.LENGTH_SHORT
//                        ).show()
//                    }
//                },
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(48.dp),
//                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
//                shape = RoundedCornerShape(24.dp)
//            ) {
//                Text("Отправить", color = Color.White, fontSize = 16.sp)
//            }
//        } else {
//            // Показываем индикатор загрузки, если задача еще не загружена
//            CircularProgressIndicator(
//                modifier = Modifier
//                    .size(48.dp)
//                    .padding(16.dp),
//                color = Color(0xFF1976D2)
//            )
//        }
//    }
//}
//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun HeadmanExhibitionScreen(navController: NavController) {
//    val scrollState = rememberScrollState()
//    var selectedTab by remember { mutableStateOf(0) } // Состояние для выбора вкладки
//    Scaffold(
//        bottomBar = {
//            Box(
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .padding(horizontal = 10.dp, vertical = 8.dp)
//            ) {
//                Card(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .height(56.dp),
//                    shape = RoundedCornerShape(28.dp),
//                    colors = CardDefaults.cardColors(containerColor = Color.White)
//                ) {
//                    Row(
//                        modifier = Modifier
//                            .fillMaxSize()
//                            .padding(horizontal = 24.dp),
//                        horizontalArrangement = Arrangement.SpaceBetween,
//                        verticalAlignment = Alignment.CenterVertically
//                    ) {
//                        Image(
//                            painter = painterResource(id = R.drawable.home_high),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .size(24.dp)
//                                .clickable {
//                                    navController.navigate(Screen.Main.route)
//                                }
//                        )
//                        Image(
//                            painter = painterResource(id = R.drawable.files_orange_high),
//                            contentDescription = null,
//                            modifier = Modifier.size(24.dp)
//                        )
//                        Image(
//                            painter = painterResource(id = R.drawable.ic_gift),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .size(24.dp)
//                                .clickable {
//                                    navController.navigate(Screen.Gifts.route)
//                                }
//                        )
//                        Image(
//                            painter = painterResource(id = R.drawable.ic_menu),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .size(24.dp)
//                                .clickable {
//                                    navController.navigate(Screen.Schedule.route)
//                                }
//                        )
//                        Image(
//                            painter = painterResource(id = R.drawable.reaccount),
//                            contentDescription = null,
//                            modifier = Modifier
//                                .size(24.dp)
//                                .clickable {
//                                    navController.navigate(Screen.More.route) {
//                                        popUpTo(navController.graph.startDestinationId)
//                                    }
//                                }
//                        )
//                    }
//                }
//            }
//        },
//        topBar = {
//            TopAppBar(
//                title = {
//                    Text(
//                        text = stringResource(R.string.tasks_for_the_headman),
//                        fontSize = 20.sp,
//                        fontWeight = FontWeight.Bold,
//                        modifier = Modifier.fillMaxWidth(),
//                        textAlign = TextAlign.Center // Центрирование заголовка
//                    )
//                },
//                navigationIcon = { /* Убираем кнопку назад */ },
//                colors = TopAppBarDefaults.topAppBarColors(
//                    containerColor = Color.White
//                )
//            )
//        }
//    ) { paddingValues ->
//        Column(
//            modifier = Modifier
//                .padding(paddingValues)
//                .fillMaxSize()
//                .verticalScroll(scrollState)
//                .padding(horizontal = 16.dp, vertical = 8.dp),
//            horizontalAlignment = Alignment.CenterHorizontally
//        ) {
//            // Добавляем кнопки Актуальное, Срочные, Архив
//            Row(
//                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
//                horizontalArrangement = Arrangement.spacedBy(12.dp)
//            ) {
//                val tabTitles = listOf("Актуальное", "Срочные", "Архив")
//                tabTitles.forEachIndexed { index, title ->
//                    val isSelected = selectedTab == index
//                    Button(
//                        onClick = { selectedTab = index },
//                        colors = if (isSelected)
//                            ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09))
//                        else
//                            ButtonDefaults.outlinedButtonColors(containerColor = Color.White),
//                        border = if (!isSelected) BorderStroke(1.dp, Color(0xFFE94F09)) else null,
//                        shape = RoundedCornerShape(50),
//                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
//                        elevation = null,
//                        modifier = Modifier.height(36.dp)
//                    ) {
//                        Text(
//                            text = title,
//                            color = if (isSelected) Color.White else Color(0xFFE94F09),
//                            fontSize = 15.sp,
//                            fontWeight = FontWeight.Medium
//                        )
//                    }
//                }
//            }
//            Image(
//                painter = painterResource(id = R.drawable.ex_1),
//                contentDescription = "ex_1",
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(160.dp) // Изображение в оригинальном размере
//                    .padding(vertical = 8.dp)
//            )
//            Image(
//                painter = painterResource(id = R.drawable.ex_2),
//                contentDescription = "ex_2",
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(160.dp) // Изображение в оригинальном размере
//                    .padding(vertical = 8.dp)
//            )
//            Image(
//                painter = painterResource(id = R.drawable.ex_3),
//                contentDescription = "ex_3",
//                modifier = Modifier
//                    .fillMaxWidth()
//                    .height(160.dp) // Изображение в оригинальном размере
//                    .padding(vertical = 8.dp)
//            )
//        }
//    }
}
