package com.rosstudent.app.constants

object ContextKeys {
    const val PREFS_NAME = "userPreferences"
    const val KEY_USER_DATA = "userData"
    const val KEY_USER_TYPE = "userType"
}