package com.rosstudent.app.data

import android.annotation.SuppressLint
import kotlinx.serialization.Serializable

// TODO: Мега-рефакторинг!!!!

enum class TaskType {
    FEDERAL, // Федеральная задача
    EDUCATIONAL, // Учебная задача
    HEADMAN // Задача от старосты
}

enum class TaskPriority {
    NORMAL, // Актуальное
    URGENT, // Срочное
    ARCHIVED // Архив
}

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class Task(
    val id: String,
    val title: String,
    val description: String,
    val type: TaskType,
    val priority: TaskPriority = TaskPriority.NORMAL,
    val deadline: String, // Формат: "до 25.04.2025"
    val createdBy: String? = null, // Кто создал (для задач от старосты)
    val createdAt: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false,
    val groupId: String? = null, // ID группы, для которой создана задача
    val isDeleted: Boolean = false // Флаг удаления
)

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class TaskRequest(
    val title: String,
    val description: String,
    val type: String,
    val priority: String = "NORMAL",
    val deadline: String,
    val groupId: String? = null // ID группы, для которой создается задача
)

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class TaskResponse(
    val id: String,
    val message: String = "Задача успешно создана"
)
@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class CompletedTask(
    val userId: String,
    val taskId: String,
    val completedAt: Long = System.currentTimeMillis()
)

@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class Question(
    val questionId: String,
    val taskId: String,
    val questionText: String,
    val questionType: String = "SINGLE_CHOICE", // SINGLE_CHOICE, MULTIPLE_CHOICE, TEXT
    val required: Boolean = true,
    val orderIndex: Int = 0
)
@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class QuestionOption(
    val optionId: String,
    val questionId: String,
    val optionText: String,
    val optionOrder: Int = 0,
    val isCorrect: Boolean = false
)
@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class Answer(
    val answerId: String,
    val questionId: String,
    val userId: String,
    val textAnswer: String? = null,
    val submittedAt: Long = System.currentTimeMillis()
)
@SuppressLint("UnsafeOptInUsageError")
@Serializable
data class SelectedOption(
    val answerId: String,
    val optionId: String
) 