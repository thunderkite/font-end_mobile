package com.rosstudent.app.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.rosstudent.app.managers.UserManager
import com.rosstudent.app.models.GuestUserModel
import com.rosstudent.app.validators.*

class RegistrationViewModel : ViewModel() {

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _registrationError = MutableStateFlow<String?>(null)
    val registrationError: StateFlow<String?> = _registrationError

    private val emailValidator = EmailValidator()
    private val nameValidator = StringMinMaxValidator(1, 50)
    private val middleNameValidator = StringMinMaxValidator(0, 50, true)
    private val passwordValidator = StringMinMaxValidator(8, 100) // Пример для пароля

    fun registerUser(
        user: GuestUserModel,
        password: String,
        confirmPassword: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _registrationError.value = null

                val validationError = validateUser(user, password, confirmPassword)
                if (validationError != null) {
                    onError(validationError)
                    return@launch
                }

                UserManager.saveUser(user)
                UserManager.loadUser()
                onSuccess()

            } catch (e: Exception) {
                val errorMessage = "Ошибка регистрации: ${e.message}"
                _registrationError.value = errorMessage
                onError(errorMessage)
            } finally {
                _isLoading.value = false
            }
        }
    }

    private fun validateUser(
        user: GuestUserModel,
        password: String,
        confirmPassword: String
    ): String? {
        val lastNameResult = nameValidator.validate(user.lastName)
        if (lastNameResult is ValidationResult.Error) {
            return "Фамилия: ${lastNameResult.message}"
        }

        val firstNameResult = nameValidator.validate(user.firstName)
        if (firstNameResult is ValidationResult.Error) {
            return "Имя: ${firstNameResult.message}"
        }

        if (!user.middleName.isNullOrBlank()) {
            val middleNameResult = middleNameValidator.validate(user.middleName!!)
            if (middleNameResult is ValidationResult.Error) {
                return "Отчество: ${middleNameResult.message}"
            }
        }

        val emailResult = emailValidator.validate(user.email)
        if (emailResult is ValidationResult.Error) {
            return "Email: ${emailResult.message}"
        }

        val passwordResult = passwordValidator.validate(password)
        if (passwordResult is ValidationResult.Error) {
            return "Пароль: ${passwordResult.message}"
        }

        if (password != confirmPassword) {
            return "Пароли не совпадают"
        }

        return null
    }

    fun clearError() {
        _registrationError.value = null
    }
}
