package com.rosstudent.app.viewmodels

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
class AuthViewModel : ViewModel() {
    private val _email = MutableStateFlow("")
    val email: StateFlow<String> = _email

    private val _password = MutableStateFlow("")
    val password: StateFlow<String> = _password

    private val _passwordVisible = MutableStateFlow(false)
    val passwordVisible: StateFlow<Boolean> = _passwordVisible

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    fun onEmailChanged(newEmail: String) {
        _email.value = newEmail
    }

    fun onPasswordChanged(newPass: String) {
        _password.value = newPass
    }


    fun login(onSuccess: () -> Unit, onError: (String) -> Unit) {
        if (_email.value.isBlank() || _password.value.isBlank()) {
            onError("Заполните все поля")
            return
        }
        // TODO: эндпоинт к серверу бла бла отправка...
        _isLoading.value = true

        _isLoading.value = false
    }

}

