package com.rosstudent.app.components

import android.annotation.SuppressLint
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.rosstudent.app.validators.ValidationResult
import com.rosstudent.app.validators.Validator
import com.rosstudent.app.R
import com.rosstudent.app.validators.StringMinMaxValidator

@Composable
fun <T> PasswordFieldComponent(
    value: T,
    onValueChange: (String) -> Unit,
    @StringRes placeholderRes: Int,
    validator: Validator<String>? = null,
    showError: Boolean = true,
    @SuppressLint("ModifierParameter") modifier: Modifier = Modifier,
) {
    var passwordVisible by remember { mutableStateOf(false) }
    var hasInteracted by remember { mutableStateOf(false) }

    val stringValue = value.toString()
    val validationResult = validator?.validate(stringValue)
    val isError = validationResult is ValidationResult.Error

    Column {
        TextFieldBase(
            value = stringValue,
            onValueChange = { newValue ->
                hasInteracted = true
                onValueChange(newValue)
            },
            placeholderRes = placeholderRes,
            modifier = modifier,
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(
                        painter = painterResource(
                            id = if (passwordVisible) R.drawable.eye else R.drawable.eye_crossed
                        ),
                        contentDescription = if (passwordVisible) {
                            stringResource(R.string.hide_password)
                        } else {
                            stringResource(R.string.show_password)
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        )

        if (showError && isError && hasInteracted) {
            Text(
                text = (validationResult as ValidationResult.Error).message,
                color = Color.Red,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 16.dp, top = 4.dp)
            )
        }
    }
}