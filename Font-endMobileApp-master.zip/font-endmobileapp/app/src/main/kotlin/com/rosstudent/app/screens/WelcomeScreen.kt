package com.rosstudent.app.screens

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.rosstudent.app.R
import com.rosstudent.app.managers.ContextManager
import com.rosstudent.app.managers.UserManager
import kotlinx.coroutines.delay

@Composable
fun WelcomeScreen(
    onTimeout: () -> Unit,
    onAutomaticLogin: () -> Unit = onTimeout
) {


    LaunchedEffect(key1 = true) {
//        val user = UserManager.loadUser()
        // Проверяем, авторизован ли пользователь
        if (UserManager.isUserExistInContext()) {
            Log.d("DEBUG_ROSS", "юзер есть")
            // Если да, сразу переходим на главный экран
            onAutomaticLogin()
//            onTimeout()
        } else {
            Log.d("DEBUG_ROSS", "юзера нету")
            // Если нет, показываем приветственный экран на 5 секунд
            delay(5000)
            onTimeout()
        }
    }
    
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.hello_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 80.dp, bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Image(
                painter = painterResource(id = R.drawable.frame_4),
                contentDescription = null,
                modifier = Modifier.size(80.dp)
            )
            Text(
                text = stringResource(R.string.welcome),
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
} 