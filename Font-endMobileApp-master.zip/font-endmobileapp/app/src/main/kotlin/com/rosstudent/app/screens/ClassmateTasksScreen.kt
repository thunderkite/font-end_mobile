package com.rosstudent.app.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.data.TaskPriority
import com.rosstudent.app.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassmateTasksScreen(navController: NavController) {
    Scaffold(
        bottomBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.home_high),
                            contentDescription = null,
                            modifier = Modifier
                                .size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Main.route)
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.files_orange_high),
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_gift),
                            contentDescription = null,
                            modifier = Modifier
                                .size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Gifts.route)
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_menu),
                            contentDescription = null,
                            modifier = Modifier
                                .size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.Schedule.route)
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.reaccount),
                            contentDescription = null,
                            modifier = Modifier
                                .size(24.dp)
                                .clickable {
                                    navController.navigate(Screen.More.route)
                                }
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(top = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.tasks_for_classmates),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            
            // Переключатели для фильтрации задач
            var selectedTab by remember { mutableStateOf(TaskPriority.NORMAL) }
            Row(
                modifier = Modifier.padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val tabTitles = listOf(
                    TaskPriority.NORMAL to "Актуальное",
                    TaskPriority.URGENT to "Срочные",
                    TaskPriority.ARCHIVED to "Архив"
                )
                tabTitles.forEach { (priority, title) ->
                    val isSelected = selectedTab == priority
                    Button(
                        onClick = { selectedTab = priority },
                        colors = if (isSelected)
                            ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09))
                        else
                            ButtonDefaults.outlinedButtonColors(containerColor = Color.White),
                        border = if (!isSelected) BorderStroke(1.dp, Color(0xFFE94F09)) else null,
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
                        elevation = null,
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text(
                            text = title,
                            color = if (isSelected) Color.White else Color(0xFFE94F09),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            
            // Карточки задач для одногруппников
            val localNavController = navController
            
            // Карточки ex_1, ex_2, ex_3 как в HeadmanExhibitionScreen
            Image(
                painter = painterResource(id = R.drawable.ex_1),
                contentDescription = "ex_1",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
                    .clickable {
                        localNavController.navigate("task_details/ex_1")
                    }
            )
            Image(
                painter = painterResource(id = R.drawable.ex_2),
                contentDescription = "ex_2",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
                    .clickable {
                        localNavController.navigate("task_details/ex_2")
                    }
            )
            Image(
                painter = painterResource(id = R.drawable.ex_3),
                contentDescription = "ex_3",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .padding(vertical = 8.dp)
                    .clickable {
                        localNavController.navigate("task_details/ex_3")
                    }
            )

            // TODO: В ViewModel запихнуть
            var tasks by remember { mutableStateOf<List<TaskPriority>>(emptyList()) }
            // Загружаем задачи из TaskStore
//            val context = LocalContext.current
//            val taskStore = remember { TaskStore(context) }
//            val userDataStore = remember { ContextController(context) }
//            var tasks by remember { mutableStateOf(emptyList<Task>()) }
//            val userData = userDataStore.getUserData()
//
//            // Загружаем задачи при изменении выбранной вкладки
//            LaunchedEffect(selectedTab) {
//                // Получаем ID группы пользователя
//                val userGroup = userData?.group
//
//                // Получаем задачи для группы пользователя с соответствующим приоритетом
//                tasks = if (userGroup != null) {
//                    val groupTasks = taskStore.getTasksByGroup(userGroup)
//                    groupTasks.filter { it.priority == selectedTab }
//                } else {
//                    taskStore.getTasksByTypeAndPriority(priority = selectedTab)
//                }
//            }
            
            // Список задач
            if (tasks.isEmpty()) {
                // Если задач нет, показываем заглушку
                Text(
                    text = stringResource(R.string.you_dont_have_any_tasks_yet),
                    color = Color.Gray,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(top = 32.dp)
                )
            }
//            else {
//                // Отображаем задачи
//                Column(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(horizontal = 16.dp),
//                    verticalArrangement = Arrangement.spacedBy(16.dp)
//                ) {
//                    tasks.forEach { task ->
//                        TaskCard(
//                            task = task,
//                            navController = navController
//                        )
//                    }
//                }
//            }
        }
    }
} 