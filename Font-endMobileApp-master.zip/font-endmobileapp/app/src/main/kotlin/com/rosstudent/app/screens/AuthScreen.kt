package com.rosstudent.app.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rosstudent.app.R
import com.rosstudent.app.components.*
import com.rosstudent.app.enums.AuthTabEnum
import com.rosstudent.app.viewmodels.AuthViewModel
import androidx.core.net.toUri
import com.rosstudent.app.validators.EmailValidator

@Composable
fun OrDivider(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFFE0E0E0))
        Text(stringResource(R.string.or), color = Color(0xFF9E9E9E), fontSize = 14.sp)
        HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFFE0E0E0))
    }
}

@Composable
fun AuthScreen(
    authViewModel: AuthViewModel,
    onNavigateToRegistration: () -> Unit = {},
    onNavigateToForgotPassword: () -> Unit = {},
    onLoginSuccess: () -> Unit = {}
) {
    val context = LocalContext.current

    var selectedTab by remember { mutableStateOf(AuthTabEnum.Login) }
    val email by authViewModel.email.collectAsState()
    val password by authViewModel.password.collectAsState()
    val passwordVisible by authViewModel.passwordVisible.collectAsState()
    val isLoading by authViewModel.isLoading.collectAsState()

    var errorMessage by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            errorMessage = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.frame_4),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomEnd)
                .height(220.dp),
            contentScale = ContentScale.FillWidth
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8F8F8))
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SpacerComponent(48)
            Image(
                painter = painterResource(id = R.drawable.frame_4),
                contentDescription = null,
                modifier = Modifier.size(80.dp),
                contentScale = ContentScale.Fit
            )
            SpacerComponent(8)
            Text(
                text = stringResource(R.string.greeting),
                fontSize = 28.sp,
                color = Color.Black,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
            SpacerComponent(32)

            AuthTabs(
                selectedTab = selectedTab,
                onTabSelected = { selectedTab = it },
                onNavigateToRegistration = onNavigateToRegistration
            )
            SpacerComponent(24)
            TextFieldComponent(
                value = email,
                onValueChange = authViewModel::onEmailChanged,
                placeholderRes = R.string.enter_your_email,
                validator = EmailValidator()
            )
            SpacerComponent(12)
            PasswordFieldComponent(
                value = password,
                onValueChange = authViewModel::onPasswordChanged,
                placeholderRes = R.string.password,
            )
            ForgotPasswordText(onNavigateToForgotPassword = onNavigateToForgotPassword)
            SpacerComponent(16)

            LoginButtonComponent(
                isLoading = isLoading,
                onClick = {
                    authViewModel.login(
                        onSuccess = onLoginSuccess,
                        onError = { errorMessage = it }
                    )
                }
            )

            SpacerComponent(24)
            OrDivider()
            SpacerComponent(16)
            // TODO: пока плевать, но надо что-то с этим делать
            GosuslugiLoginButtonComponent(onClick = {
                val intent = Intent(Intent.ACTION_VIEW, "https://sufficiently-enlivening-leech.cloudpub.ru/".toUri())
                context.startActivity(intent)
            })

            SpacerComponent(12)
        }
    }
}
