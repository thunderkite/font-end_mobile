package com.rosstudent.app.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import android.R.drawable.ic_menu_view
import android.R.drawable.ic_menu_close_clear_cancel
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.components.CustomTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChangePasswordScreen(navController: NavController) {
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Верхняя панель
        TopAppBar(
            title = {
                Text(
                    text = stringResource(R.string.change_password),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium
                )
            },
            navigationIcon = {
                IconButton(onClick = { navController.navigateUp() }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.White
            )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .padding(top = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Текущий пароль
            CustomTextField(
                value = currentPassword,
                onValueChange = { currentPassword = it },
                placeholderText = stringResource(R.string.current_password),
                isPassword = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Новый пароль
            CustomTextField(
                value = newPassword,
                onValueChange = { newPassword = it },
                placeholderText = stringResource(R.string.new_password),
                isPassword = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Подтверждение нового пароля
            CustomTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                placeholderText = stringResource(R.string.confirm_the_new_password),
                isPassword = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.weight(1f))

            // Кнопка изменения пароля
            Button(
                onClick = { /* Обработка изменения пароля */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE94F09)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = stringResource(R.string.change),
                    color = Color.White,
                    fontSize = 16.sp
                )
            }
        }
    }
}