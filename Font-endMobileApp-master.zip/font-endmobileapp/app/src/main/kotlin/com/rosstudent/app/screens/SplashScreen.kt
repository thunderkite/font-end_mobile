package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rosstudent.app.R
import kotlinx.coroutines.delay

/**
 * Загрузочный экран приложения
 */
@Composable
fun SplashScreen(onSplashComplete: () -> Unit = {}) {
    LaunchedEffect(key1 = true) {
        delay(2000) // Показываем сплеш 2 секунды
        onSplashComplete()
    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp)
        ) {
            // Верхняя иконка
            Image(
                painter = painterResource(id = R.drawable.icon_1),
                contentDescription = "top icon",
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 48.dp)
                    .size(width = 99.dp, height = 136.dp)
            )

            // Текст "Росстудент"
            Text(
                text = stringResource(R.string.rosstudent),
                fontSize = 48.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth()
            )
        }

        // Нижняя иконка
        Image(
            painter = painterResource(id = R.drawable.icon_2),
            contentDescription = "Нижняя иконка",
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .fillMaxWidth()
                .height(500.dp)
                .align(Alignment.BottomCenter)
        )
    }
}
