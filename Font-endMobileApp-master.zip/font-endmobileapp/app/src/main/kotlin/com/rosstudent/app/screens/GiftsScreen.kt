package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.navigation.Screen
import androidx.annotation.DrawableRes
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.layout.ContentScale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GiftsScreen(navController: NavController) {
    // Use a Box to stack the main content (scrollable column) and the fixed bottom bar
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5)) // Светло-серый фон по скриншоту
    ) {
        // Main content column (scrollable)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp) // Отступ снизу, чтобы контент не перекрывался нижним баром
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(24.dp)) // Отступ сверху
            // Заголовок по центру
            Text(
                text = stringResource(R.string.gifts_and_bonuses),
                fontSize = 20.sp, // Размер шрифта по скриншоту
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                textAlign = TextAlign.Center
            )

            // Поле поиска
            OutlinedTextField(
                value = "", // Состояние поля поиска
                onValueChange = { /* TODO: Обработка ввода */ },
                placeholder = { Text(stringResource(R.string.search)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = stringResource(R.string.search)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(24.dp), // Скругленные углы
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFF5F5F5),
                    unfocusedContainerColor = Color(0xFFF5F5F5),
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = Color(0xFFE94F09)
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Горизонтальный список иконок
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp), // Отступы по горизонтали
                horizontalArrangement = Arrangement.spacedBy(16.dp) // Расстояние между элементами
            ) {
                val items = listOf(
                    CategoryItemData(R.drawable.new_icon, "Новые"),
                    CategoryItemData(R.drawable.pop_icon, "Популярные"),
                    CategoryItemData(R.drawable.food_icon, "Еда"),
                    CategoryItemData(R.drawable.leisure_icon, "Досуг"),
                    CategoryItemData(R.drawable.sub_icon, "Подписки"),
                    CategoryItemData(R.drawable.train_item, "Обучение")
                )
                items(items) {
                    HorizontalCategoryItem(it.icon, it.title) { /* TODO: Обработка нажатия на категорию */ }
                }
            }
            // Здесь можно добавить остальной контент страницы, который будет прокручиваться вместе с категориями

            Spacer(modifier = Modifier.height(24.dp)) // Отступ перед новой секцией

            // Секция "Популярное"
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp) // Отступы по бокам как на скриншоте
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.popular),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(end = 4.dp) // Небольшой отступ между текстом и иконкой
                    )
                    // Используем fire_icon
                    Image(
                        painter = painterResource(id = R.drawable.fire_icon),
                        contentDescription = "popular",
                        modifier = Modifier.size(20.dp) // Размер иконки
                    )
                }

                Spacer(modifier = Modifier.height(16.dp)) // Отступ между заголовком и горизонтальным списком

                // Горизонтальный список карточек "Популярное"
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp) // Расстояние между карточками
                ) {
                    // Пример карточки 2 (с ad_1)
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp), // Увеличиваем ширину карточки до 300dp
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_1), // Используем ad_1
                                contentDescription = "advertising image 1",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize() // Изображение заполняет всю карточку
                            )
                        }
                    }

                    // Пример карточки 3 (с ad_2 и текстом)
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp), // Увеличиваем ширину карточки до 300dp
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Box(modifier = Modifier.fillMaxSize()){
                                Image(
                                    painter = painterResource(id = R.drawable.ad_2), // Используем ad_2
                                    contentDescription = "advertising image 1",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize() // Изображение заполняет всю карточку
                                )
                                Text(
                                    text = "Мате...", // Примерный текст по скриншоту
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(8.dp)
                                )
                            }
                        }
                    }

                    // Добавьте другие карточки по необходимости
                }
            }

            Spacer(modifier = Modifier.height(24.dp)) // Отступ перед новой секцией "Новое"

            // Секция "Новое"
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp) // Отступы по бокам как на скриншоте
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.latest),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp)) // Отступ между заголовком и горизонтальным списком

                // Горизонтальный список карточек "Новое"
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp) // Расстояние между карточками
                ) {
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp)) // Отступ перед новой секцией "Рестораны"

            // Секция "Рестораны"
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp) // Отступы по бокам как на скриншоте
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.restaurants),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = stringResource(R.string.all),
                        fontSize = 14.sp,
                        color = Color(0xFFE94F09), // Примерный оранжевый цвет
                        modifier = Modifier.clickable { /* TODO: Добавить действие для "Все" */ }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp)) // Отступ между заголовком и горизонтальным списком

                // Горизонтальный список карточек "Рестораны"
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp) // Расстояние между карточками
                ) {
                    // Пример карточки 1 (с ad_3)
                    item {
                        Column(
                            modifier = Modifier.width(300.dp) // Устанавливаем ширину карточки на 300dp
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp), // Устанавливаем высоту изображения на 160dp
                                shape = RoundedCornerShape(8.dp),
                                onClick = { /* TODO: Добавить действие для карточки ресторана */ }
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ad_3), // Используем ad_3
                                    contentDescription = "restaurant image 1",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp)) // Отступ между изображением и текстом
                            Text(
                                text = stringResource(R.string.reception_cafe), // Изменяем название
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = stringResource(R.string.little_cafe), // Примерный текст адреса
                                fontSize = 12.sp,
                                color = Color.Gray,
                                lineHeight = 16.sp // Уменьшаем расстояние между строками
                            )
                        }
                    }

                    // Пример карточки 2 (с ad_4)
                    item {
                        Column(
                            modifier = Modifier.width(300.dp) // Устанавливаем ширину карточки на 300dp
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp), // Устанавливаем высоту изображения на 160dp
                                shape = RoundedCornerShape(8.dp),
                                onClick = { /* TODO: Добавить действие для карточки ресторана */ }
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ad_4), // Используем ad_4
                                    contentDescription = "restaurant image 2",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp)) // Отступ между изображением и текстом
                            Text(
                                text = stringResource(R.string.reception_cafe), // Изменяем название
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = stringResource(R.string.little_cafe), // Примерный текст адреса
                                fontSize = 12.sp,
                                color = Color.Gray,
                                lineHeight = 16.sp // Уменьшаем расстояние между строками
                            )
                        }
                    }

                    // Добавьте другие карточки ресторанов по необходимости
                }
            }

            Spacer(modifier = Modifier.height(24.dp)) // Отступ перед новой секцией "Досуг"

            // Секция "Досуг"
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp) // Отступы по бокам
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.leisure),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = stringResource(R.string.all),
                        fontSize = 14.sp,
                        color = Color(0xFFE94F09), // Примерный оранжевый цвет
                        modifier = Modifier.clickable { /* TODO: Добавить действие для "Все" */ }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp)) // Отступ между заголовком и горизонтальным списком

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp) // Расстояние между карточками
                ) {
                    // Карточка 1 (с ad_5)
                    item {
                        Column(
                            modifier = Modifier.width(300.dp) // Ширина карточки
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp), // Высота изображения
                                shape = RoundedCornerShape(8.dp),
                                onClick = { /* TODO: Добавить действие для карточки досуга */ }
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ad_5), // Используем ad_5
                                    contentDescription = "leisure image 1",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp)) // Отступ между изображением и текстом
                            Text(
                                text = stringResource(R.string.name_of_leisure_1), // Placeholder текст
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = stringResource(R.string.brief_description_of_leisure_1), // Placeholder текст
                                fontSize = 12.sp,
                                color = Color.Gray,
                                lineHeight = 16.sp // Уменьшаем расстояние между строками
                            )
                        }
                    }

                    // Карточка 2 (с ad_6)
                    item {
                        Column(
                            modifier = Modifier.width(300.dp) // Ширина карточки
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp), // Высота изображения
                                shape = RoundedCornerShape(8.dp),
                                onClick = { /* TODO: Добавить действие для карточки досуга */ }
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.ad_6), // Используем ad_6
                                    contentDescription = "leisure image 2",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp)) // Отступ между изображением и текстом
                            Text(
                                text = stringResource(R.string.name_of_leisure_2), // Placeholder текст
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = stringResource(R.string.brief_description_of_leisure_2), // Placeholder текст
                                fontSize = 12.sp,
                                color = Color.Gray,
                                lineHeight = 16.sp // Уменьшаем расстояние между строками
                            )
                        }
                    }

                    // Добавьте другие карточки досуга по необходимости
                }
            }

            Spacer(modifier = Modifier.height(24.dp)) // Отступ перед новой секцией "Подписки"

            // Секция "Подписки"
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.subscriptions),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp)) // Отступ перед новой секцией "Обучения"

            // Секция "Обучения"
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Обучения",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp)) // Отступ перед новой секцией "Покупки"

            // Секция "Покупки"
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.purchases),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp)) // Отступ перед новой секцией "Прочее"

            // Секция "Прочее"
            Column(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.other),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    item {
                        Card(
                            modifier = Modifier.width(300.dp).height(160.dp),
                            shape = RoundedCornerShape(8.dp),
                            onClick = { /* TODO: Добавить действие для карточки */ }
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ad_7),
                                contentDescription = "advertising image 7",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }

        // Нижняя навигация
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter) // Выравниваем по нижнему центру
                .padding(horizontal = 10.dp, vertical = 8.dp) // Отступы по горизонтали и вертикали
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.home_high),
                        contentDescription = null,
                        modifier = Modifier
                            .size(24.dp)
                            .clickable {
                                navController.navigate(Screen.Main.route) {
                                    popUpTo(Screen.Main.route) { inclusive = true }
                                }
                            }
                    )
                    Image(
                        painter = painterResource(id = R.drawable.ic_document),
                        contentDescription = null,
                        modifier = Modifier
                            .size(24.dp)
                            .clickable {
                                navController.navigate(Screen.Tasks.route)
                            }
                    )
                    // Активная иконка подарков
                    Image(
                        painter = painterResource(id = R.drawable.ic_gift),
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                        colorFilter = ColorFilter.tint(Color(0xFFE94F09))
                    )
                    Image(
                        painter = painterResource(id = R.drawable.ic_menu),
                        contentDescription = null,
                        modifier = Modifier
                            .size(24.dp)
                            .clickable {
                                navController.navigate(Screen.Schedule.route)
                            }
                    )
                    Image(
                        painter = painterResource(id = R.drawable.reaccount), // Заменяем иконку
                        contentDescription = null,
                        modifier = Modifier
                            .size(24.dp)
                            .clickable {
                                navController.navigate(Screen.More.route) {
                                    popUpTo(navController.graph.startDestinationId) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                    )
                }
            }
        }
    }
}

private data class CategoryItemData(
    @DrawableRes val icon: Int,
    val title: String
)

@Composable
private fun HorizontalCategoryItem(
    @DrawableRes icon: Int,
    title: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Image(
            painter = painterResource(id = icon),
            contentDescription = title,
            modifier = Modifier.size(48.dp) // Размер иконки по скриншоту
        )
        Spacer(modifier = Modifier.height(4.dp)) // Расстояние между иконкой и текстом
        Text(
            text = title,
            fontSize = 12.sp, // Размер шрифта по скриншоту
            color = Color.Black,
            textAlign = TextAlign.Center
        )
    }
}

// Секция "Досуг" - Добавляем новую секцию
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeisureSection() {
    Column(
        modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 16.dp) // Отступы по бокам
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.leisure),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = stringResource(R.string.all),
                fontSize = 14.sp,
                color = Color(0xFFE94F09), // Примерный оранжевый цвет
                modifier = Modifier.clickable { /* TODO: Добавить действие для "Все" */ }
            )
        }

        Spacer(modifier = Modifier.height(16.dp)) // Отступ между заголовком и горизонтальным списком

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(16.dp) // Расстояние между карточками
        ) {
            // Карточка 1 (с ad_5)
            item {
                Column(
                    modifier = Modifier.width(300.dp) // Ширина карточки
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp), // Высота изображения
                        shape = RoundedCornerShape(8.dp),
                        onClick = { /* TODO: Добавить действие для карточки досуга */ }
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ad_5), // Используем ad_5
                            contentDescription = "name of leisure 1",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp)) // Отступ между изображением и текстом
                    Text(
                        text = "name of leisure 1", // Placeholder текст
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = stringResource(R.string.brief_description_of_leisure_1), // Placeholder текст
                        fontSize = 12.sp,
                        color = Color.Gray,
                        lineHeight = 16.sp // Уменьшаем расстояние между строками
                    )
                }
            }

            // Карточка 2 (с ad_6)
            item {
                Column(
                    modifier = Modifier.width(300.dp) // Ширина карточки
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp), // Высота изображения
                        shape = RoundedCornerShape(8.dp),
                        onClick = { /* TODO: Добавить действие для карточки досуга */ }
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ad_6), // Используем ad_6
                            contentDescription = "image of leisure 2",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp)) // Отступ между изображением и текстом
                    Text(
                        text = "name of leisure 2", // Placeholder текст
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = stringResource(R.string.brief_description_of_leisure_2), // Placeholder текст
                        fontSize = 12.sp,
                        color = Color.Gray,
                        lineHeight = 16.sp // Уменьшаем расстояние между строками
                    )
                }
            }

            // Добавьте другие карточки досуга по необходимости
        }
    }
} 