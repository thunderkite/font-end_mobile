package com.rosstudent.app.navigation

import android.util.Log
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.rosstudent.app.screens.AuthScreen
import com.rosstudent.app.screens.RegistrationScreen
import com.rosstudent.app.screens.MainScreen
import com.rosstudent.app.screens.OpportunitiesAndBenefitsScreen
import com.rosstudent.app.screens.YouthRightsScreen
import com.rosstudent.app.screens.AccountScreen
import com.rosstudent.app.screens.HomeScreen
import com.rosstudent.app.screens.TaskScreen
import com.rosstudent.app.screens.ScheduleScreen
import com.rosstudent.app.screens.GroupListScreen
import com.rosstudent.app.screens.StudentDetailsScreen
import com.rosstudent.app.screens.GiftsScreen
import com.rosstudent.app.screens.EditProfileScreen
import com.rosstudent.app.screens.ChangePasswordScreen
import com.rosstudent.app.screens.EmailConfirmationScreen
import com.rosstudent.app.screens.ForgotPasswordEmailScreen
import com.rosstudent.app.screens.ForgotPasswordCodeScreen
import com.rosstudent.app.screens.ForgotPasswordNewPasswordScreen
import com.rosstudent.app.screens.ForgotPasswordSuccessScreen
import com.rosstudent.app.screens.WelcomeScreen
import com.rosstudent.app.screens.StudentRightsScreen
import com.rosstudent.app.screens.ClassmateTasksScreen
import com.rosstudent.app.screens.CreateTaskScreenWithQuestions
import com.rosstudent.app.screens.HeadmanTasksDetailScreen
import com.rosstudent.app.screens.TaskAnswersScreen
import com.rosstudent.app.viewmodels.AuthViewModel

@Composable
fun SetupNavGraph(navController: NavHostController) {


    val isHeadman = false


    NavHost(
        navController = navController,
        startDestination = Screen.Welcome.route
    ) {
        composable(route = Screen.Welcome.route) {
            WelcomeScreen(
                onTimeout = {
                    // TODO: проверить что сессия устапрела и на ауфроут. Если нет интернета то сохраняем состояние и даем доступ к оффлайн функциям
                    navController.navigate(Screen.Auth.route) {
                        popUpTo(Screen.Welcome.route) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onAutomaticLogin = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Welcome.route) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }
        
        composable(route = Screen.Auth.route) {
            val authViewModel: AuthViewModel = viewModel()
            AuthScreen(
                authViewModel = authViewModel,
                onNavigateToRegistration = {
                    navController.navigate(Screen.Registration.route)
                },
                onNavigateToForgotPassword = {
                    navController.navigate(Screen.ForgotPasswordEmail.route)
                },
                onLoginSuccess = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Auth.route) { inclusive = true }
                    }
                }
            )
        }
        
        composable(route = Screen.Registration.route) {
            RegistrationScreen(
                onNavigateToLogin = {
                    navController.navigate(Screen.Auth.route) {
                        popUpTo(Screen.Auth.route) { inclusive = true }
                    }
                },
                onRegistrationSuccess = {
                    Log.d("Registration", "Registration success")
//                    navController.navigate(Screen.EmailConfirmation.route) {
//                        popUpTo(Screen.Registration.route) { inclusive = true }
//                    }
                },
            )
        }

        composable(route = Screen.ForgotPasswordEmail.route) {
            ForgotPasswordEmailScreen(
                onSendCode = { navController.navigate(Screen.ForgotPasswordCode.route) }
            )
        }

        composable(route = Screen.ForgotPasswordCode.route) {
            ForgotPasswordCodeScreen(
                onCodeConfirmed = { navController.navigate(Screen.ForgotPasswordNewPassword.route) }
            )
        }

        composable(route = Screen.ForgotPasswordNewPassword.route) {
            ForgotPasswordNewPasswordScreen(
                onPasswordChanged = { navController.navigate(Screen.ForgotPasswordSuccess.route) }
            )
        }

        composable(route = Screen.ForgotPasswordSuccess.route) {
            ForgotPasswordSuccessScreen(
                onReturn = { navController.navigate(Screen.Auth.route) }
            )
        }

        composable(route = Screen.Main.route) {
            MainScreen(navController = navController)
        }

        composable(route = Screen.OpportunitiesAndBenefits.route) {
            OpportunitiesAndBenefitsScreen(navController = navController)
        }

        composable(route = Screen.YouthRights.route) {
            YouthRightsScreen(navController = navController)
        }

        composable(route = Screen.StudentRights.route) {
            StudentRightsScreen(navController = navController)
        }

        composable(route = Screen.Account.route) {
            AccountScreen(navController = navController, isHeadman = isHeadman)
        }

        composable(route = Screen.Home.route) {
            HomeScreen(navController = navController)
        }

        composable(route = Screen.Tasks.route) {
            val currentIsHeadman = isHeadman
            TaskScreen(
                navController = navController,
                isHeadman = currentIsHeadman
            )
        }

        composable(route = Screen.Schedule.route) {
            ScheduleScreen(
                navController = navController,
                isHeadman = isHeadman
            )
        }

        composable(route = "group_list/{lessonId}") { backStackEntry ->
            val lessonId = backStackEntry.arguments?.getString("lessonId") ?: return@composable
            GroupListScreen(
                navController = navController,
                isHeadman = isHeadman
            )
        }

        composable(route = "student_details/{studentId}") { backStackEntry ->
            val studentId = backStackEntry.arguments?.getString("studentId")?.toIntOrNull() ?: return@composable
            StudentDetailsScreen(
                studentId = studentId,
                onBackClick = {
                    navController.popBackStack()
                }
            )
        }

        composable(route = Screen.Gifts.route) {
            GiftsScreen(navController = navController)
        }

        composable(route = Screen.EditProfile.route) {
            EditProfileScreen(navController = navController)
        }

        composable(route = Screen.ChangePassword.route) {
            ChangePasswordScreen(navController = navController)
        }

        composable(route = Screen.EmailConfirmation.route) {
            EmailConfirmationScreen(
                onRegister = {
                    navController.navigate(Screen.Auth.route) {
                        popUpTo(Screen.EmailConfirmation.route) { inclusive = true }
                    }
                }
            )
        }

        composable(route = Screen.More.route) {
            navController.navigate(Screen.Account.route) {
                popUpTo(navController.graph.startDestinationId) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }

        composable("headman_tasks_detail") {
            HeadmanTasksDetailScreen(navController = navController)
        }
        
        // Экран создания задачи старостой
        composable("create_task") {
            CreateTaskScreenWithQuestions(navController = navController)
        }

        // Экран для отображения ex_1, ex_2, ex_3 при клике на ex_4
//        composable("headman_exhibition_ex4") {
//            HeadmanExhibitionScreen(navController = navController)
//        }

        // Экран для задач одногруппников
        composable("classmate_tasks") {
            ClassmateTasksScreen(navController = navController)
        }

        // Экраны для деталей задач
//        composable("task_details/{taskId}") { backStackEntry ->
//            val taskId = backStackEntry.arguments?.getString("taskId") ?: return@composable
//            TaskDetailsScreen(
//                taskId = taskId,
//                navController = navController
//            )
//        }
        
        composable("task_answers/{taskId}") { backStackEntry ->
            val taskId = backStackEntry.arguments?.getString("taskId") ?: return@composable
            TaskAnswersScreen(
                taskId = taskId,
                navController = navController
            )
        }

//        composable("task_details/ex_1") {
//            TaskDetailsScreen(
//                taskId = "ex_1",
//                navController = navController
//            )
//        }
//
//        composable("task_details/ex_2") {
//            TaskDetailsScreen(
//                taskId = "ex_2",
//                navController = navController
//            )
//        }
//
//        composable("task_details/ex_3") {
//            TaskDetailsScreen(
//                taskId = "ex_3",
//                navController = navController
//            )
//        }
    }
} 