package com.rosstudent.app.managers

import android.annotation.SuppressLint
import android.content.Context

@SuppressLint("StaticFieldLeak")
object ContextManager {
    private lateinit var context: Context

    fun initialize(context: Context) {
        this.context = context.applicationContext
    }

    fun logContext() {
        if (::context.isInitialized) {
            println("Context: $context")
        } else {
            println("Context не инициализирован")
        }
    }

    fun isContextExists(): Boolean {
        return ::context.isInitialized
    }

    fun getContext(): Context {
        return context
    }
}