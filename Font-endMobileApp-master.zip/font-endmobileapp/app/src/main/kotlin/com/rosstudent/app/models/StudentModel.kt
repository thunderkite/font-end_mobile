package com.rosstudent.app.models

import com.rosstudent.app.enums.EducationType
import com.rosstudent.app.enums.RolesType
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
@SerialName("Student")
data class StudentModel(
    @SerialName("user_id")
    override val userId: String,
    @SerialName("first_name")
    override val firstName: String,
    @SerialName("last_name")
    override val lastName: String,
    @SerialName("email")
    override val email: String,
    @SerialName("middle_name")
    override val middleName: String? = null,
    @SerialName("education_type")
    val educationType: EducationType,
    @SerialName("education_name")
    val educationName: String,
    @SerialName("student_group")
    val studentGroup: String? = null
) : UserBaseModel() {
    @SerialName("role")
    override val role: RolesType = RolesType.Student

}