package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.rosstudent.app.R
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.res.stringResource
import com.rosstudent.app.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Composable
fun OpportunitiesAndBenefitsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.opportunities_and_benefits),
                        fontSize = 20.sp, // Увеличиваем размер шрифта
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Start, // Выравниваем по левому краю
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 24.dp) // Увеличиваем отступ слева для смещения вправо
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            painter = painterResource(id = R.drawable.back_arrow),
                            contentDescription = "Back"
                        )
                    }
                }
            )
        },
        bottomBar = {
            // Нижняя навигация (островок стиль)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp) // Отступы по горизонтали и вертикали
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp), // Высота карточки
                    shape = RoundedCornerShape(28.dp), // Скругленные углы для островка
                    colors = CardDefaults.cardColors(containerColor = Color.White) // Белый фон
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp), // Внутренние отступы
                        horizontalArrangement = Arrangement.SpaceBetween, // Распределение иконок
                        verticalAlignment = Alignment.CenterVertically // Выравнивание по центру по вертикали
                    ) {
                        // Иконки навигации
                        Image(
                            painter = painterResource(id = R.drawable.home_high), // Замените на вашу иконку Главная
                            contentDescription = "Main",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Главную */
                                    navController.navigate(Screen.Main.route) {
                                        popUpTo(navController.graph.startDestinationId) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_document), // Замените на вашу иконку Документы
                            contentDescription = "Documents",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Документы */
                                    navController.navigate(Screen.Tasks.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_gift), // Замените на вашу иконку Подарки
                            contentDescription = "Gifts",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Подарки */
                                    navController.navigate(Screen.Gifts.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_menu), // Замените на вашу иконку Список/Меню
                            contentDescription = "List",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Список/Меню */
                                    navController.navigate(Screen.Schedule.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.reaccount), // Заменяем иконку
                            contentDescription = "More",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Еще */
                                    navController.navigate(Screen.More.route) {
                                        popUpTo(navController.graph.startDestinationId) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(top = 16.dp) // Увеличиваем отступ сверху
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Большая карточка "Права молодежи и студентов"
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(8.dp)),
                onClick = { 
                    navController.navigate(Screen.YouthRights.route)
                }
            ) {
                Box(
                    modifier = Modifier.fillMaxSize()
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.permission),
                        contentDescription = "youth and student rights",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Секция с Вакансиями, Грантами и Обучением
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Карточка Вакансии и стажировка
                Image(
                    painter = painterResource(id = R.drawable.vacancy),
                    contentDescription = "vacancies and internships",
                    modifier = Modifier
                        .weight(1.9f)
                        .fillMaxWidth()
                        .clickable { /* TODO: Добавить навигацию */ }
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.FillWidth
                )

                // Карточки Гранты и Обучение (вложенный столбец)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .height(300.dp)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Карточка Гранты
                    Image(
                        painter = painterResource(id = R.drawable.grants),
                        contentDescription = "grants",
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { /* TODO: Добавить навигацию */ }
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )

                    // Карточка Обучение
                    Image(
                        painter = painterResource(id = R.drawable.training),
                        contentDescription = "training",
                        modifier = Modifier
                            .weight(0.7f)
                            .fillMaxHeight()
                            .clickable { /* TODO: Добавить навигацию */ }
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            // Секция "Важное"
            Row(
                modifier = Modifier.fillMaxWidth()
                    .clickable { /* TODO: Добавить действие для заголовка Важное */ },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.important),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Next"
                )
            }

            // Горизонтальный список карточек (Права студентов, Социальная стипендия, Материальная помощь)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    // Права студентов
                    Card(
                        modifier = Modifier.size(140.dp, 100.dp), // Устанавливаем примерный размер по скриншоту
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFA726)), // Оранжевый цвет
                        onClick = { /* TODO: Добавить навигацию */ }
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(8.dp),
                            contentAlignment = Alignment.BottomStart
                        ) {
                            Text(
                                text = stringResource(R.string.students_rights),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
                item {
                    // Социальная стипендия
                    Card(
                        modifier = Modifier.size(140.dp, 100.dp), // Устанавливаем примерный размер по скриншоту
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF66BB6A)), // Зеленый цвет
                        onClick = { /* TODO: Добавить навигацию */ }
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(8.dp),
                            contentAlignment = Alignment.BottomStart
                        ) {
                            Text(
                                text = stringResource(R.string.social_scholarship),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
                item {
                    // Материальная помощь
                    Card(
                        modifier = Modifier.size(140.dp, 100.dp), // Устанавливаем примерный размер по скриншоту
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFD54F)), // Желтый цвет
                        onClick = { /* TODO: Добавить навигацию */ }
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().padding(8.dp),
                            contentAlignment = Alignment.BottomStart
                        ) {
                            Text(
                                text = stringResource(R.string.financial_assistance),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Секция "Чат-бот "Молодые правозащитники""
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = stringResource(R.string.chatbot),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = stringResource(R.string.ask_the_chatbot),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Кнопка "Перейти в чат-бот во ВКонтакте"
                Card(
                    modifier = Modifier.fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(8.dp),
                    onClick = { /* TODO: Добавить действие для VK */ }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // TODO: Используйте реальную иконку VK
                            Image(
                                painter = painterResource(id = R.drawable.vk), // Используйте вашу иконку VK
                                contentDescription = "VK",
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = stringResource(R.string.chatbot_in_vk),
                                fontSize = 16.sp
                            )
                        }
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Далее")
                    }
                }

                // Кнопка "Перейти в чат-бот в Телеграм"
                Card(
                    modifier = Modifier.fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(8.dp),
                    onClick = { /* TODO: Добавить действие для Telegram */ }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // TODO: Используйте реальную иконку Telegram
                            Image(
                                painter = painterResource(id = R.drawable.telegram), // Используйте вашу иконку Telegram
                                contentDescription = "Telegram",
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = stringResource(R.string.chatbot_in_telegram),
                                fontSize = 16.sp
                            )
                        }
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Далее")
                    }
                }
            }

            // Добавьте другие элементы страницы здесь, если необходимо
        }
    }
}

fun navigateToAccountScreen() {
    // Логика навигации на экран 'Аккаунт'
    // Например, использование NavController для навигации
} 
