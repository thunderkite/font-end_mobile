package com.rosstudent.app.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import com.rosstudent.app.R
import com.rosstudent.app.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YouthRightsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Права молодёжи и студентов",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        },
        bottomBar = {
            // Нижняя навигация (островок стиль)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp) // Отступы по горизонтали и вертикали
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp), // Высота карточки
                    shape = RoundedCornerShape(28.dp), // Скругленные углы для островка
                    colors = CardDefaults.cardColors(containerColor = Color.White) // Белый фон
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp), // Внутренние отступы
                        horizontalArrangement = Arrangement.SpaceBetween, // Распределение иконок
                        verticalAlignment = Alignment.CenterVertically // Выравнивание по центру по вертикали
                    ) {
                        // Иконки навигации
                        Image(
                            painter = painterResource(id = R.drawable.home_high), // Замените на вашу иконку Главная
                            contentDescription = "Main",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Главную */
                                    navController.navigate(Screen.Main.route) {
                                        popUpTo(navController.graph.startDestinationId) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_document), // Замените на вашу иконку Документы
                            contentDescription = "Documents",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Документы */
                                    navController.navigate(Screen.Tasks.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_gift), // Замените на вашу иконку Подарки
                            contentDescription = "Gifts",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Подарки */
                                    navController.navigate(Screen.Gifts.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.ic_menu), // Замените на вашу иконку Список/Меню
                            contentDescription = "List",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Список/Меню */
                                    navController.navigate(Screen.Schedule.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                        Image(
                            painter = painterResource(id = R.drawable.reaccount), // Заменяем иконку
                            contentDescription = "More",
                            modifier = Modifier.size(24.dp) // Размер иконки
                                .clickable {
                                    /* TODO: Навигация на Еще */
                                    navController.navigate(Screen.More.route) {
                                        popUpTo(navController.graph.startDestinationId) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(top = 24.dp, start = 16.dp, end = 16.dp, bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.student_rights),
                contentDescription = "Student Rights",
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { navController.navigate(Screen.StudentRights.route) },
                contentScale = ContentScale.FillWidth
            )
            
            Image(
                painter = painterResource(id = R.drawable.train_rights),
                contentDescription = "Train Rights",
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.FillWidth
            )
            
            Image(
                painter = painterResource(id = R.drawable.work_rights),
                contentDescription = "Work Rights",
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.FillWidth
            )
            
            Image(
                painter = painterResource(id = R.drawable.family_rights),
                contentDescription = "Family Rights",
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.FillWidth
            )
            
            Image(
                painter = painterResource(id = R.drawable.war_family_rights),
                contentDescription = "War Family Rights",
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.FillWidth
            )

            Image(
                painter = painterResource(id = R.drawable.health_rights),
                contentDescription = "Health Rights",
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.FillWidth
            )

            // Секция "Чат-бот "Молодые правозащитники""
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = stringResource(R.string.chatbot),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = stringResource(R.string.ask_the_chatbot),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Кнопка "Перейти в чат-бот во ВКонтакте"
                Card(
                    modifier = Modifier.fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(8.dp),
                    onClick = { /* TODO: Добавить действие для VK */ }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // TODO: Используйте реальную иконку VK
                            Image(
                                painter = painterResource(id = R.drawable.vk), // Используйте вашу иконку VK
                                contentDescription = "VK",
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = stringResource(R.string.chatbot_in_vk),
                                fontSize = 16.sp
                            )
                        }
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Далее")
                    }
                }

                // Кнопка "Перейти в чат-бот в Телеграм"
                Card(
                    modifier = Modifier.fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(8.dp),
                    onClick = { /* TODO: Добавить действие для Telegram */ }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // TODO: Используйте реальную иконку Telegram
                            Image(
                                painter = painterResource(id = R.drawable.telegram), // Используйте вашу иконку Telegram
                                contentDescription = "Telegram",
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = stringResource(R.string.chatbot_in_telegram),
                                fontSize = 16.sp
                            )
                        }
                        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Next")
                    }
                }
            }
        }
    }
} 