package com.rosstudent.app.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rosstudent.app.enums.AuthTabEnum
import com.rosstudent.app.theme.SelectedColor
import com.rosstudent.app.theme.UnderlineHeight
import com.rosstudent.app.theme.UnderlineWidth
import com.rosstudent.app.theme.UnselectedColor

@Composable
fun AuthTabs(
    selectedTab: AuthTabEnum,
    onTabSelected: (AuthTabEnum) -> Unit,
    onNavigateToRegistration: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AuthTabEnum.entries.forEach { tab ->
            val isSelected = tab == selectedTab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable {
                        if (tab == AuthTabEnum.Registration) {
                            onNavigateToRegistration()
                        } else {
                            onTabSelected(tab)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = tab.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isSelected) SelectedColor else UnselectedColor
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    if (isSelected) {
                        Box(
                            Modifier
                                .height(UnderlineHeight)
                                .width(UnderlineWidth)
                                .background(SelectedColor)
                        )
                    }
                }
            }
        }
    }
}
