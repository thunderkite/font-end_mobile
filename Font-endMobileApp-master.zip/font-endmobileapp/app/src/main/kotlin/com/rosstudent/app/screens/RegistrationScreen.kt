package com.rosstudent.app.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rosstudent.app.R
import com.rosstudent.app.components.PasswordFieldComponent
import com.rosstudent.app.components.SpacerComponent
import com.rosstudent.app.components.TextFieldComponent
import com.rosstudent.app.models.GuestUserModel
import com.rosstudent.app.utils.Debug
import com.rosstudent.app.validators.EmailValidator
import com.rosstudent.app.validators.StringMinMaxValidator
import com.rosstudent.app.viewmodels.RegistrationViewModel

@Composable
fun RegistrationScreen(
    onNavigateToLogin: () -> Unit = {},
    onRegistrationSuccess: () -> Unit = {}
) {
    val vm: RegistrationViewModel = viewModel()
    val context = LocalContext.current

    var guestModel by remember { mutableStateOf(GuestUserModel("", "", "", "")) }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }


    // Collect ViewModel state
    val isLoading by vm.isLoading.collectAsState()

    val scrollState = rememberScrollState()

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8F8F8))
                .padding(horizontal = 24.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SpacerComponent(36)

            // Logo
            Image(
                painter = painterResource(id = R.drawable.frame_4),
                contentDescription = null,
                modifier = Modifier.size(80.dp)
            )
            SpacerComponent(8)

            // Greeting
            Text(
                text = stringResource(R.string.greeting),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            SpacerComponent(24)

            // Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToLogin() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = stringResource(R.string.entrance),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.Black
                        )
                        SpacerComponent(4)
                        Box(
                            Modifier
                                .height(2.dp)
                                .width(40.dp)
                                .background(Color.Transparent)
                        )
                    }
                }
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = stringResource(R.string.registration),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFE94F09)
                        )
                        SpacerComponent(4)
                        Box(
                            Modifier
                                .height(2.dp)
                                .width(80.dp)
                                .background(Color(0xFFE94F09))
                        )
                    }
                }
            }
            SpacerComponent(24)
            TextFieldComponent(
                value = guestModel.lastName,
                onValueChange = {
                    guestModel = guestModel.copy(lastName = it)
                },
                placeholderRes = R.string.enter_your_lastname,
                validator = StringMinMaxValidator(1, 50)
            )
            SpacerComponent(12)
            TextFieldComponent(
                value = guestModel.firstName,
                onValueChange = {
                    guestModel = guestModel.copy(firstName = it)
                },
                placeholderRes = R.string.firstname,
                validator = StringMinMaxValidator(1, 50)
            )
            SpacerComponent(12)

            TextFieldComponent(
                value = guestModel.middleName ?: "",
                onValueChange = {
                    guestModel = guestModel.copy(middleName = it.takeIf { text -> text.isNotBlank() })
                },
                placeholderRes = R.string.patronymic_if_any,
                validator = StringMinMaxValidator(0, 50, true),
                showError = false
            )
            SpacerComponent(12)
            TextFieldComponent(
                value = guestModel.email,
                onValueChange = {
                    guestModel = guestModel.copy(email = it)
                },
                placeholderRes = R.string.enter_your_email,
                validator = EmailValidator()
            )

            SpacerComponent(12)

            Text(
                text = stringResource(R.string.come_up_with_a_strong_password),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.Black,
                modifier = Modifier.align(Alignment.Start)
            )
            SpacerComponent(8)

            PasswordFieldComponent(
                password,
                onValueChange = { password = it }, R.string.password
            )
            SpacerComponent(12)

            PasswordFieldComponent(
                confirmPassword,
                onValueChange = { confirmPassword = it }, R.string.repeat_password
            )
            SpacerComponent(24)

            Button(
                onClick = {
                    vm.registerUser(
                        guestModel,
                        onSuccess = {
                            Debug.log("success")
//                            onRegistrationSuccess()
                        },
                        onError = { error ->
                            Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                        },
                        password = password,
                        confirmPassword = confirmPassword
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6088FF)),
                shape = RoundedCornerShape(14.dp),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    Text(
                        stringResource(R.string.registration_process),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Text(
                        stringResource(R.string.register),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
